"""Reproduce the published forces from CSV using Python's standard library."""
import csv
import json
import math
from pathlib import Path

EXAMPLES = Path(__file__).resolve().parents[1] / "examples"
CUBES = EXAMPLES / "04_three_cubes_forces"
EMPTY = EXAMPLES / "05_empty_force_surface"
STEPS = range(51)
TARGETS = (1, 2, 3)
SOURCES = (0, 1, 2, 3)
COMPONENTS = ("Fx_N", "Fy_N", "Fz_N", "Mx_Nm", "My_Nm", "Mz_Nm")


def read_series(path, *, grouped):
    """Index one row per time and receiver, optionally also by source group."""
    series = {}
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            step = int(row["step"])
            key = (step, int(row["target_i"]))
            if grouped:
                key += (int(row["source_j"]),)
            if key in series or not math.isclose(float(row["time_s"]), step * 0.0004, abs_tol=1e-12):
                raise ValueError(f"{path.name}: duplicate row or inconsistent time at {key}")
            series[key] = row
    expected = {(s, i, j) for s in STEPS for i in TARGETS for j in SOURCES} if grouped else {
        (s, i) for s in STEPS for i in TARGETS
    }
    if set(series) != expected:
        raise ValueError(f"{path.name}: unexpected time or group IDs")
    return series


def components(row, prefix):
    values = [float(row[prefix + name]) for name in COMPONENTS]
    if not all(math.isfinite(value) for value in values):
        raise ValueError(f"Invalid component at step {row['step']}")
    return values


def sum_pairs(series, step, receiver, prefix):
    vectors = [components(series[step, receiver, j], prefix) for j in SOURCES]
    return [math.fsum(column) for column in zip(*vectors)]


def report_peak(vectors, expected_step, expected_magnitude):
    magnitudes = [math.hypot(*vector[:3]) for vector in vectors]
    step = max(STEPS, key=magnitudes.__getitem__)
    if step != expected_step or not math.isclose(magnitudes[step], expected_magnitude, rel_tol=2e-12):
        raise ValueError(f"Unexpected peak {magnitudes[step]} N at step {step}")
    return {"step": step, "time_s": step * 0.0004, "magnitude_N": magnitudes[step]}


def main():
    cubes = read_series(CUBES / "forces.csv", grouped=True)
    empty = read_series(EMPTY / "forces.csv", grouped=True)
    surface = read_series(EMPTY / "surfaces.csv", grouped=False)
    for (step, receiver), row in surface.items():
        total = sum_pairs(empty, step, receiver, "")
        reference = components(row, "grouped_")
        if any(not math.isclose(a, b, rel_tol=2e-13, abs_tol=1e-18) for a, b in zip(total, reference)):
            raise ValueError(f"Pair sum differs from surfaces.csv at step {step}, receiver {receiver}")

    peaks = {}
    for method, expected in (("panels", 0.0018332215323353808), ("faces", 0.0018509830961195204)):
        vectors = [sum_pairs(cubes, step, 1, method + "_") for step in STEPS]
        peaks["cube_1_" + method] = report_peak(vectors, 32, expected)
    vectors = [sum_pairs(empty, step, 3, "") for step in STEPS]
    peaks["empty_3_sum_of_pairs"] = report_peak(vectors, 35, 0.000035263016985634895)
    vectors = [components(surface[step, 3], "fullB_") for step in STEPS]
    peaks["empty_3_full_field"] = report_peak(vectors, 34, 0.000008521360999759622)
    print(json.dumps({"steps": len(STEPS), "pair_rows_per_CSV": len(cubes),
                      "six_component_sums_checked": len(surface), "peaks": peaks}, indent=2))


if __name__ == "__main__":
    main()

