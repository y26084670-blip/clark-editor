"""Compare a CLARK air-gap CSV with the FEMM DC solution at identical positions."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from matplotlib.tri import Triangulation


ROOT = Path(__file__).resolve().parent


def compare(clark_csv, ans, radius_mm):
    with clark_csv.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError("The CLARK point table is empty.")
    xyz = np.array([[float(row[k]) for k in ("X_mm", "Y_mm", "Z_mm")] for row in rows])
    field = np.array([[float(row[k]) for k in ("B_X_T", "B_Y_T", "B_Z_T")] for row in rows])
    y, z = xyz[:, 1:].T
    radii = np.hypot(y, z)
    if not np.all(np.isfinite(field)) or not np.allclose(xyz[:, 0], 0, rtol=0, atol=1e-6):
        raise ValueError("Expected finite B and coordinates in the X=0 midplane.")
    if not np.isfinite(radius_mm) or radius_mm <= 0 or not np.allclose(radii, radius_mm, rtol=0, atol=1e-4):
        raise ValueError("The selected CLARK points must lie on the declared air-gap radius.")

    lines = ans.read_text(encoding="utf-8-sig").splitlines()
    start = lines.index("[Solution]")
    head = {}
    for line in lines[:start]:
        if line.startswith("[") and "=" in line:
            name, value = line.split("=", 1)
            head[name.strip().strip("[]")] = value.strip().strip('"')
    if head.get("ProblemType") != "planar" or head.get("LengthUnits") != "millimeters" or float(head["Frequency"]) != 0:
        raise ValueError("This comparison supports planar FEMM DC snapshots in millimetres.")
    materials = [s.split("=", 1)[1].strip().strip('"') for s in lines[:start] if s.strip().startswith("<BlockName>")]
    first_label = next(i for i,line in enumerate(lines) if line.startswith("[NumBlockLabels]")) + 1
    label_material = [materials[int(s.split()[2]) - 1] for s in lines[first_label:first_label + int(head["NumBlockLabels"])]]
    n = int(lines[start + 1])
    data = np.array([list(map(float, s.split()[:3])) for s in lines[start + 2:start + 2 + n]])
    first = start + 2 + n
    elems = np.array([list(map(int, s.split()[:4])) for s in lines[first + 1:first + 1 + int(lines[first])]])
    yy, zz, ax = data.T
    if "FEMM_triangle_1based" in rows[0]:
        owners = np.array([int(row["FEMM_triangle_1based"]) - 1 for row in rows])
    else:
        owners = Triangulation(yy, zz, elems[:, :3]).get_trifinder()(y, z)
    if np.any(owners < 0) or np.any(owners >= len(elems)) or any(label_material[v] != "Air" for v in elems[owners, 3]):
        raise ValueError("Some CLARK locations cannot be associated with an air triangle.")
    a, b, c = elems[owners, :3].T
    u1, v1, u2, v2 = yy[b] - yy[a], zz[b] - zz[a], yy[c] - yy[a], zz[c] - zz[a]
    det = u1 * v2 - u2 * v1
    if np.any(det <= 0):
        raise ValueError("Invalid FEMM triangle orientation.")
    w1 = ((y - yy[a]) * v2 - (z - zz[a]) * u2) / det
    w2 = (u1 * (z - zz[a]) - v1 * (y - yy[a])) / det
    if np.any(np.minimum.reduce([w1, w2, 1 - w1 - w2]) < -1e-7):
        raise ValueError("Stored FEMM triangle references disagree with the point coordinates.")
    d1, d2 = ax[b] - ax[a], ax[c] - ax[a]
    by = 1000 * (u1 * d2 - u2 * d1) / det
    bz = -1000 * (v2 * d1 - v1 * d2) / det
    ref = np.column_stack((np.zeros_like(by), by, bz))
    delta = field - ref
    norm = np.linalg.norm(ref)
    if norm == 0:
        raise ValueError("Relative comparison is undefined for an identically zero reference.")
    radial, tang = y / radii, z / radii
    error = np.linalg.norm(delta, axis=1)
    columns = ["angle_deg", "Y_mm", "Z_mm", "CLARK_Br_T", "FEMM_Br_T", "CLARK_Bt_T", "FEMM_Bt_T", "delta_B_norm_T"]
    angle = np.degrees(np.arctan2(z, y)) % 360
    angle[np.isclose(angle, 360., atol=1e-9, rtol=0)] = 0.
    samples = zip(angle, y, z, field[:, 1] * radial + field[:, 2] * tang,
                  by * radial + bz * tang, -field[:, 1] * tang + field[:, 2] * radial, -by * tang + bz * radial, error)
    stats = dict(rows=len(rows), distinct_positions=len(np.unique(np.round(xyz, 6), axis=0)), radius_mm=radius_mm,
                 vector_relative_L2_percent=100 * float(np.linalg.norm(delta) / norm),
                 rms_delta_B_mT=1000 * float(np.sqrt(np.mean(error ** 2))), max_delta_B_mT=1000 * float(error.max()))
    return stats, columns, samples


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--clark-csv", type=Path, default=ROOT / "reference/CLARK_gap_120m.csv")
    parser.add_argument("--ans", type=Path, default=ROOT / "source/TVV320_control_point1.ans")
    parser.add_argument("--radius-mm", type=float, default=585.)
    parser.add_argument("--out", type=Path, help="Optional new CSV for pointwise results.")
    args = parser.parse_args()
    stats, columns, samples = compare(args.clark_csv, args.ans, args.radius_mm)
    if args.out:
        with args.out.open("x", encoding="utf-8-sig", newline="") as out:
            writer = csv.writer(out)
            writer.writerow(columns)
            writer.writerows(samples)
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
