"""Build the calibrated TVV-320 planar example from a FEMM DC file.

The CLARK input generator needs Python 3.10+ and the standard library.
The optional ANS comparison uses NumPy and Matplotlib.
"""
import argparse
import csv
import hashlib
import json
import math
import re
import tempfile
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MU0 = 4e-7 * math.pi


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_rows(path, rows):
    with path.open("w", encoding="utf-8", newline="\n") as out:
        for row in rows:
            out.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")


def write_csv(path, columns, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as out:
        w = csv.writer(out)
        w.writerow(columns)
        w.writerows(rows)


def keyed(text, pattern):
    return {k: v.strip().strip('"') for k, v in re.findall(pattern, text, re.M)}


def read_fem(path, profile):
    text = path.read_text(encoding="utf-8-sig")
    lines = text.splitlines()
    # Dimensions, material laws, circuit names, polarity and numbering belong to
    # this calibrated sector layout. Only real DC circuit currents may vary.
    masked = "\n".join("<TotalAmps_re>" if s.strip().startswith("<TotalAmps_re>") else s for s in lines)
    signature = hashlib.sha256(masked.encode()).hexdigest()
    require(signature == profile["fem_structure_sha256"],
            "This sector profile is calibrated for TVV320_control_point1.fem. A different geometry needs its own layout.")
    header = keyed(text, r"^\[([^]]+)\]\s*=\s*([^\r\n]*)")
    require(header["ProblemType"] == "planar" and header["LengthUnits"] == "millimeters"
            and float(header["Frequency"]) == 0, "Expected a planar DC problem in millimetres.")

    def table(name):
        start = next(i for i, line in enumerate(lines) if line.startswith("[" + name + "]"))
        return [row.split() for row in lines[start + 1:start + 1 + int(header[name])]]

    currents = {}
    for block in re.findall(r"<BeginCircuit>(.*?)<EndCircuit>", text, re.S | re.I):
        p = keyed(block, r"<([^>]+)>\s*=\s*([^\r\n]+)")
        currents[p["CircuitName"]] = float(p["TotalAmps_re"])
    require(len(currents) == int(header["CircuitProps"]) and all(map(math.isfinite, currents.values())),
            "Invalid circuit table.")
    circuits = list(currents)
    materials = {}
    for block in re.findall(r"<BeginBlock>(.*?)<EndBlock>", text, re.S):
        p = keyed(block, r"<([^>]+)>\s*=\s*([^\r\n]+)")
        data = block.split("<BHPoints>", 1)[1].strip().splitlines()[1:]
        bh = [tuple(map(float, row.split())) for row in data]
        require(len(bh) == int(p["BHPoints"]), "B(H) length differs from the file header.")
        materials[p["BlockName"]] = bh
    names = list(materials)
    labels = []
    for i, row in enumerate(table("NumBlockLabels")):
        c = int(row[4])
        labels.append(dict(index=i, y=float(row[0]), z=float(row[1]), material=names[int(row[2]) - 1],
                           circuit=circuits[c - 1] if c else "", group=int(row[6]), turns=int(row[7])))
    return lines, header, currents, materials, labels, table


def winding_sections(table, labels):
    points = [(float(p[0]), float(p[1])) for p in table("NumPoints")]
    groups = {lab["group"] for lab in labels if lab["circuit"]}
    adjacency = defaultdict(lambda: defaultdict(list))
    for row in table("NumSegments"):
        group = int(row[5])
        if group in groups:
            a, b = map(int, row[:2])
            adjacency[group][a].append(b)
            adjacency[group][b].append(a)
    result = []
    for group, edges in adjacency.items():
        require(all(len(v) == 2 for v in edges.values()), "Open or branched winding boundary.")
        remaining = set(edges)
        while remaining:
            first = min(remaining)
            previous, current = None, first
            corners = []
            while current in remaining:
                remaining.remove(current)
                corners.append(points[current])
                a, b = edges[current]
                previous, current = current, b if a == previous else a
            require(current == first and len(corners) == 4, "Expected a closed four-sided winding section.")
            pairs = list(zip(corners, corners[1:] + corners[:1]))
            area = abs(sum(y * v - z * u for (y, z), (u, v) in pairs)) / 2

            def contains(lab):
                side = [(b[0] - a[0]) * (lab["z"] - a[1]) - (b[1] - a[1]) * (lab["y"] - a[0])
                        for a, b in pairs]
                return min(side) > 0 or max(side) < 0

            inside = [lab for lab in labels if lab["group"] == group and contains(lab)]
            require(area > 0 and len(inside) == 1, "Expected one FEMM winding label inside each contour.")
            result.append(dict(**inside[0], area=area))
    ids = {r["index"] for r in result}
    require(len(result) == len(ids) == sum(bool(l["circuit"]) for l in labels), "Unmatched FEMM label.")
    return result


def rotated(y, z, degrees):
    angle = math.radians(degrees)
    return (y * math.cos(angle) - z * math.sin(angle),
            y * math.sin(angle) + z * math.cos(angle))


def build_geometry(profile, length, windings, currents):
    kvs, native_j, assignments, yz_vertices = [], [], [], []
    used = set()
    for index, row in enumerate(profile["sectors"], 1):
        coil = row["material"] == "coil"
        kv = profile["winding_defaults" if coil else "magnetic_defaults"].copy()
        r0, r1, width = row["inner_mm"], row["outer_mm"], row["width_deg"]
        oy, oz = row["offset_yz_mm"]
        theta = row["first_deg"] - 90
        sym = dict(vi=[theta, 0, 0], r0=[0, 0, 0], ls=row["copies"], yl=row["pitch_deg"],
                   ya=row["azimuth_step_deg"], ps=1, tx=0, kya=row["parity"], kyp=0)
        sym["as"] = row["azimuth_count"]
        x = length / 2
        kv.update(name=row["name"], geo=[-x, r0, x, r0, x, r1, -x, r1, width] + [0] * 15,
                  dr=[0, oy, oz], sym=sym, dp=row["dp"], xapName="" if coil else row["material"])
        kvs.append(kv)
        tangent = math.tan(math.radians(width / 2))
        for i in range(sym["ls"]):
            primary = None
            for a in range(sym["as"]):
                angle = theta + i * sym["yl"] + a * sym["ya"]
                yz_vertices.extend(rotated(sign * radius * tangent + oy, radius + oz, angle)
                                   for radius in (r0, r1) for sign in (-1, 1))
                if not coil:
                    continue
                center = rotated(oy, (r0 + r1) / 2 + oz, angle)
                winding = min(windings, key=lambda w: math.dist(center, (w["y"], w["z"])))
                require(math.dist(center, (winding["y"], winding["z"])) < 1e-6
                        and winding["index"] not in used, "Missing or duplicated winding at a sector centre.")
                used.add(winding["index"])
                amps = currents[winding["circuit"]] * winding["turns"]
                density = amps / winding["area"]
                sector_area = (r1 * r1 - r0 * r0) * tangent
                require(math.isclose(sector_area, winding["area"], rel_tol=1e-7), "Winding area mismatch.")
                if a == 0 or sym["kya"] == 0:
                    native_j.append(density)
                else:
                    require(math.isclose(density, primary * sym["kya"] ** a, abs_tol=1e-8),
                            "Specified currents conflict with the winding symmetry.")
                if a == 0:
                    primary = density
                assignments.append((index, i + 1, a + 1, winding["index"] + 1, winding["circuit"],
                                    winding["turns"], winding["area"], amps, density))
    require(len(used) == len(windings), "Some physical windings are missing from CLARK.")
    span = [max(v) - min(v) for v in zip(*yz_vertices)]
    require(profile["general"]["mirrorSymmetryX"] < 0 and all(k["dp"][0] == 1 for k in kvs)
            and length > 2 * max(span), "Axial length or divisions do not satisfy the CLARK 2D criterion.")
    mhj = [{"v": native_j + [0.] * (2 * len(native_j))}]
    return kvs, mhj, assignments, span


def compare_ans(path, fem_lines, labels, docs, currents, original_currents):
    import numpy as np
    from matplotlib.tri import Triangulation

    lines = path.read_text(encoding="utf-8-sig").splitlines()
    i = lines.index("[Solution]")
    require(lines[:i] == fem_lines, "The FEM and ANS input sections do not match.")
    n = int(lines[i + 1])
    nodes = np.array([list(map(float, r.split())) for r in lines[i + 2:i + 2 + n]])
    j = i + 2 + n
    count = int(lines[j])
    cells = np.array([list(map(int, r.split()[:4])) for r in lines[j + 1:j + 1 + count]])
    triangles, ids = cells[:, :3], cells[:, 3]
    require(len(cells) == count and len(nodes) == n and np.isfinite(nodes).all()
            and triangles.min() >= 0 and triangles.max() < n and ids.min() >= 0 and ids.max() < len(labels),
            "Invalid ANS nodes, element references or material labels.")
    u, v, ax = nodes[:, :3].T
    tri = Triangulation(u, v, triangles)
    # Half-degree sample positions avoid the sector seams. The reported B is the
    # unsmoothed gradient on the containing FEM triangle, with lengths in m.
    theta = np.arange(360) + .5
    c, s = np.cos(np.radians(theta)), np.sin(np.radians(theta))
    yy, zz = 585. * c, 585. * s
    owners = tri.get_trifinder()(yy, zz)
    require(np.all(owners >= 0) and all(labels[ids[k]]["material"] == "Air" for k in owners),
            "Air-gap sampling circle is outside air in this ANS.")
    n0, n1, n2 = triangles[owners].T
    uy, uz = u[n1] - u[n0], v[n1] - v[n0]
    vy, vz = u[n2] - u[n0], v[n2] - v[n0]
    determinant = uy * vz - uz * vy
    require(np.all(determinant > 0), "Invalid triangle orientation on the sampling circle.")
    da, db = ax[n1] - ax[n0], ax[n2] - ax[n0]
    by = 1000 * (uy * db - vy * da) / determinant
    bz = -1000 * (vz * da - uz * db) / determinant
    br, bt = by * c + bz * s, -by * s + bz * c
    write_csv(docs / "FEMM_gap.csv", ["angle_deg", "Y_mm", "Z_mm", "B_Y_T", "B_Z_T", "B_r_T", "B_t_T"],
              zip(theta, yy, zz, by, bz, br, bt))
    return dict(nodes=n, triangles=count, matches_input_section=True,
                matches_requested_currents=currents == original_currents, gap_radius_mm=585,
                gap_samples=len(owners), max_abs_Br_T=float(np.max(np.abs(br))),
                max_abs_Bt_T=float(np.max(np.abs(bt))), source_Ax_range_Wb_per_m=[float(ax.min()), float(ax.max())])


def generate(args, dest):
    profile = json.loads((ROOT / "profile/tvv320.json").read_text(encoding="utf-8"))
    lines, header, original, materials, labels, table = read_fem(args.fem, profile)
    currents = original.copy()
    for setting in args.current:
        name, value = setting.split("=", 1)
        require(name in currents and math.isfinite(float(value)), "Unknown circuit or invalid current.")
        currents[name] = float(value)
    length = args.length_mm if args.length_mm is not None else float(header["Depth"])
    require(math.isfinite(length) and length > 0, "Invalid extrusion length.")
    windings = winding_sections(table, labels)
    kvs, mhj, assignments, span = build_geometry(profile, length, windings, currents)
    inp, docs = dest / "input3XX", dest / "DOCS"
    (inp / "xapLibFMM").mkdir(parents=True)
    docs.mkdir()
    for name, rows in [("general", [profile["general"]]), ("conrab", profile["conrab"]), ("kvs", kvs),
                       ("tks", profile["regions"]), ("mhj", mhj), ("amplitudes", profile["amplitudes"]),
                       ("moves", profile["moves"])]:
        write_rows(inp / (name + ".txt"), rows)
    for name, bh in materials.items():
        if bh:
            h = [row[1] / 1000 for row in bh]
            m = [(b / MU0 - field) / 1000 for b, field in bh]
            write_json(inp / "xapLibFMM" / (name + ".txt"), dict(tabl=h + m, hip=0.0,
                       comment="FEMM B(H) → CLARK M(H), кА/м. Все исходные пары сохранены."))
    (inp / "_nogo.e3d").write_text("Проверить и сохранить задание в Editor.\n", encoding="utf-8")
    write_csv(docs / "windings.csv", ["KV", "local_copy", "azimuth_copy", "FEM_label_1based", "circuit",
              "signed_turns", "area_mm2", "ampere_turns_signed_A", "J_X_A_per_mm2"], assignments)
    report = dict(fem=args.fem.name, fem_sha256=hashlib.sha256(args.fem.read_bytes()).hexdigest(),
                  source_FEMM_depth_mm=float(header["Depth"]), clark_length_x_mm=length, transverse_span_yz_mm=span,
                  FEMM_frequency_Hz=float(header["Frequency"]), source_currents_A=original, effective_currents_A=currents,
                  fem_entities={k: int(header[k]) for k in ("NumPoints", "NumSegments", "NumArcSegments", "NumBlockLabels")},
                  fem_labels_by_material=dict(Counter(lab["material"] for lab in labels)),
                  steel_BH_points={k: len(v) for k, v in materials.items() if v},
                  magnetic_KV=sum(s["material"] != "coil" for s in profile["sectors"]),
                  winding_KV=sum(s["material"] == "coil" for s in profile["sectors"]),
                  physical_windings=len(windings), independent_prescribed_EO=len(mhj[0]["v"]) // 3,
                  magnetic_EO=sum(math.prod(k["dp"]) * k["sym"]["ls"] * k["sym"]["as"] for k in kvs if k["targ"] == 0),
                  geometry_source="Calibrated large sector layout for this FEMM cross-section; longitudinal span and current snapshot supplied separately.",
                  field_source="FEMM ANS" if args.ans else None, clark_solver_run=False)
    if args.ans:
        report["ans"] = compare_ans(args.ans, lines, labels, docs, currents, original)
        report["ans_sha256"] = hashlib.sha256(args.ans.read_bytes()).hexdigest()
    write_json(docs / "checks.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fem", type=Path, default=ROOT / "source/TVV320_control_point1.fem")
    parser.add_argument("--ans", type=Path, help="Optional FEMM solution for the input snapshot.")
    parser.add_argument("--current", action="append", default=[], metavar="CIRCUIT=AMP",
                        help="Override one DC circuit for the new CLARK input. May be repeated.")
    parser.add_argument("--length-mm", type=float, help="CLARK length along X. Default is the FEMM depth for this case.")
    parser.add_argument("--out", type=Path, required=True, help="New CLARK case directory.")
    args = parser.parse_args()
    target = args.out.resolve()
    require(not target.exists(), f"Output already exists: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
        staged = Path(tmp) / "case"
        report = generate(args, staged)
        require(not target.exists(), f"Output already exists: {target}")
        staged.rename(target)
    print(f"{target} | {report['magnetic_KV']} magnetic + {report['winding_KV']} winding records")


if __name__ == "__main__":
    main()
