"""Prepare isolated task copies, compile FMUs and execute reproducible runs."""
import csv
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

from .configuration import Circuit, Records, load_circuit, text_file
from .model import ResidualFMU
from .protocol import Client, Session, encode
from .simulation import solve
from .transports import Bridge, DirectTransport, LegacyFiles, ZmqTransport

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = 'fmi-case.json'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2)+'\n', encoding='utf-8')


def read_case(directory, require_fmu=False):
    root = Path(directory).resolve()
    info = json.loads((root/MANIFEST).read_text(encoding='utf-8'))
    if info.get('schema') != 1:
        raise ValueError('Unsupported FMI case schema')
    for name, expected in info['inputs'].items():
        if digest(root/name) != expected:
            raise ValueError(f'Prepared input changed: {name}; prepare a new run directory')
    circuit = Circuit(**json.loads((root/'circuit.json').read_text(encoding='utf-8')))
    if require_fmu and (not info.get('fmu_sha256') or digest(root/'circuit.fmu') != info['fmu_sha256']):
        raise ValueError('Build this case FMU first, or prepare a new case if it has changed')
    return root, circuit, info


def prepare(source, destination):
    source, target = Path(source).resolve(), Path(destination).resolve()
    if target == source or source in target.parents:
        raise ValueError('Run directory must be outside the original task')
    circuit = load_circuit(source)
    if circuit.server and not (source/'input3XX'/'general.txt').is_file():
        raise ValueError('Import the legacy task to input3XX first; use a working Julia task copy')
    target.mkdir(parents=True, exist_ok=False)
    (target/'sources').mkdir()
    shutil.copy2(source/'circuit-config.txt', target/'sources'/'circuit-config.original.txt')
    # Only the solver inputs are needed; do not copy gigabytes of old field results.
    if circuit.server:
        shutil.copytree(source/'input3XX', target/'input3XX')
    records = Records(text_file(source/'circuit-config.txt').splitlines(), 1)
    records.read(2)
    canonical = ['FMI copy of current CircuitClient inputs', f'{circuit.phases} {circuit.parallel}']
    for phase in range(circuit.phases):
        name = records.read()[0].replace('\\', '/')
        path = source/name
        captured = f'sources/waveform-{phase+1:03d}.txt'
        if path.is_file():
            shutil.copy2(path, target/captured)
        canonical.append(captured)
        for branch in range(circuit.parallel):
            records.read(4)
            b = circuit.branches[phase*circuit.parallel+branch]
            canonical.append(f"{b['pulse']} {b['coil']} {b['L']:.17g} {b['R']:.17g}")
    canonical.extend([str(int(circuit.floating)), format(circuit.amplitude, '.17g'), str(circuit.material),
                      format(circuit.tolerance, '.17g'), format(circuit.increment, '.17g')])
    if not circuit.server:
        canonical.extend(['Local fixed grid', format(circuit.local_grid['dt'], '.17g'), str(circuit.local_grid['steps'])])
    (target/'circuit-config.txt').write_text('\n'.join(canonical)+'\n', encoding='utf-8')
    write_json(target/'circuit.json', circuit.to_dict())
    template = ROOT/'modelica'/'ClarkCircuit.mo'
    shutil.copy2(template, target/'ClarkCircuit.mo')
    numbers = lambda key: '{'+','.join(format(b[key], '.17g') for b in circuit.branches)+'}'
    model = ('within;\nmodel ClarkCase\n  extends ClarkCircuit.CircuitResidual(\n'
             f'    nPhase={circuit.phases}, nParallel={circuit.parallel},\n'
             f'    floatingNeutral={str(circuit.floating).lower()},\n'
             f'    L={numbers("L")}, R={numbers("R")});\nend ClarkCase;\n')
    (target/'ClarkCase.mo').write_text(model, encoding='utf-8')
    paths = [p for p in target.rglob('*') if p.is_file()]
    info = dict(schema=1, source=str(source), created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                inputs={p.relative_to(target).as_posix(): digest(p) for p in sorted(paths)},
                fmu_sha256=None, prototype='CircuitClient discrete residual; FMI 2.0 ME')
    write_json(target/MANIFEST, info)
    return target


def build(directory, omc='omc', cc=None):
    root, _, info = read_case(directory)
    compiler = shutil.which(omc) or str(Path(omc).resolve())
    version = subprocess.run([compiler, '--version'], check=True, capture_output=True, text=True).stdout.strip()
    # Compile in the case directory to retain diagnostics; never reuse an old FMU as success.
    generated = root/'ClarkCase.fmu'
    generated.unlink(missing_ok=True)
    script = ('loadFile("ClarkCircuit.mo");\nloadFile("ClarkCase.mo");\n'
              'buildModelFMU(ClarkCase, version="2.0", fmuType="me", fileNamePrefix="ClarkCase");\n'
              'getErrorString();\n')
    if cc:
        script = 'setCompiler('+json.dumps(cc)+');\n'+script
    (root/'build.mos').write_text(script, encoding='utf-8')
    completed = subprocess.run([compiler, 'build.mos'], cwd=root, capture_output=True, text=True, errors='replace')
    (root/'build.log').write_text(version+'\n'+completed.stdout+'\n'+completed.stderr, encoding='utf-8')
    if completed.returncode or not generated.is_file():
        raise RuntimeError(f'FMU build failed; see {root / "build.log"}')
    from fmpy import read_model_description
    description = read_model_description(str(generated), validate=True)
    if description.modelExchange is None or description.fmiVersion != '2.0':
        raise ValueError('Compiler did not produce FMI 2.0 Model Exchange')
    shutil.copy2(generated, root/'circuit.fmu')
    info.update(omc_version=version, fmu_guid=description.guid, fmu_sha256=digest(root/'circuit.fmu'),
                build_platform=platform.platform())
    write_json(root/MANIFEST, info)
    return root/'circuit.fmu'


def run(directory, transport='zmq', timeout=600, endpoint=None):
    root, circuit, info = read_case(directory, require_fmu=True)
    output = root/'fmi-results'
    output.mkdir(exist_ok=False)  # A repeated run requires another prepared copy.
    bridge = connection = model = field = None
    metadata = dict(case=info, transport=transport if circuit.server else 'local',
                    python=sys.version, platform=platform.platform(), complete=False)
    import fmpy
    metadata['fmpy'] = fmpy.__version__
    write_json(output/'run.json', metadata)
    try:
        grid = circuit.local_grid
        if circuit.server:
            if endpoint:
                if transport != 'zmq':
                    raise ValueError('--endpoint requires --transport zmq')
                connection = ZmqTransport(endpoint, timeout+10)
            else:
                adapter = LegacyFiles(root, timeout)
                if transport == 'files':
                    connection = DirectTransport(Session(adapter))
                else:
                    bridge = Bridge(adapter).start()
                    connection = ZmqTransport(bridge.endpoint, timeout+10)
            field = Client(connection, [b['pulse'] for b in circuit.branches], [b['coil'] for b in circuit.branches])
            grid = field.grid
            metadata['negotiation'] = field.description
        metadata['grid'] = grid
        write_json(output/'run.json', metadata)
        model = ResidualFMU(root/'circuit.fmu', circuit, grid)
        with (output/'steps.jsonl').open('x', encoding='utf-8') as states, \
             (output/'iterations.jsonl').open('x', encoding='utf-8') as iterations, \
             (output/'currents.tsv').open('x', encoding='utf-8', newline='') as table:
            writer = csv.writer(table, delimiter='\t', lineterminator='\n')
            writer.writerow(['step', 'time_s', *[f'I{i+1}_A' for i in range(circuit.n)], 'neutral_V', 'residual_norm'])
            def snapshot(value):
                states.write(encode(value).decode()+'\n')
                states.flush()
                writer.writerow([value['step'], value['time_s'], *value['current_A'], value['neutral_V'], value['residual_norm']])
                table.flush()
                print(f"step={value['step']} time={value['time_s']:.17g} residual={value['residual_norm']:.6g}", flush=True)
            def trace(value):
                iterations.write(encode(value).decode()+'\n')
                iterations.flush()
            result = solve(circuit, grid, model, field, snapshot, trace)
        metadata.update(complete=True, endpoints=len(result),
                        history_commit_ack=False if field else None,
                        note='Field run also requires successful server exit recorded by the owner launcher')
        write_json(output/'run.json', metadata)
        return output
    except BaseException as error:
        metadata.update(complete=False, error=f'{type(error).__name__}: {error}')
        write_json(output/'run.json', metadata)
        raise
    finally:
        try:
            if model:
                model.close()
        finally:
            try:
                if connection:
                    connection.close()
            finally:
                if bridge:
                    bridge.close()


def doctor(omc='omc'):
    import fmpy
    import numpy
    import zmq
    print(f'Python: {sys.version.split()[0]} ({platform.machine()}); executable: {sys.executable}')
    print(f'FMPy: {fmpy.__version__}; numpy: {numpy.__version__}; pyzmq: {zmq.__version__}; libzmq: {zmq.zmq_version()}')
    result = subprocess.run([omc, '--version'], check=True, capture_output=True, text=True)
    print(result.stdout.strip())
    return 0
