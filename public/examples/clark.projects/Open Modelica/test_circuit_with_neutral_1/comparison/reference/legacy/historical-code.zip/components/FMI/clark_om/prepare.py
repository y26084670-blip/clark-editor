"""One-time input conversion. No integration, nonlinear solve or field launch."""
import argparse
import json
import math
import os
from pathlib import Path
import re
import tempfile

from clark_fmi.configuration import load_circuit


def read_pulses(raw):
    """Read task JSON Lines without changing its bytes or the 1-based indices."""
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError(f'Duplicate pulse JSON key: {key}')
            result[key] = value
        return result
    pulses = []
    for line in raw.decode('utf-8-sig').splitlines():
        if not line.strip():
            raise ValueError('Empty record in amplitudes.txt')
        pulse = json.loads(line, object_pairs_hook=pairs)
        n = pulse.get('n') if isinstance(pulse, dict) else None
        values = pulse.get('impuls') if isinstance(pulse, dict) else None
        if type(n) is not int or not 2 <= n <= 2**31-1 or not isinstance(values, list) or len(values) != 2*n:
            raise ValueError('Pulse requires n >= 2 and exactly 2*n flattened values')
        if any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
            raise ValueError('Pulse values must be finite numbers')
        if any(b <= a for a, b in zip(values[:n], values[1:n])):
            raise ValueError('Pulse times must increase')
        pulses.append(pulse)
    return pulses


def model_id(phases, parallel, floating):
    return f"circuit-p{phases}-b{parallel}-{'floating' if floating else 'grounded'}"


def write_new(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')


def prepare(source, version='1.1.0'):
    source = Path(source).resolve()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}', version) or '..' in version:
        raise ValueError('Invalid model version')
    inputs = source / 'input3XX'
    if not inputs.is_dir():
        raise ValueError('Expected an ordinary task with input3XX')
    targets = [inputs / name for name in ('om-client.json', 'circuit-config.json', 'server-config.json')]
    if any(p.exists() for p in targets):
        raise FileExistsError('OM input files already exist; edit the existing task data')
    amplitude_path = inputs / 'amplitudes.txt'
    original_amplitudes = amplitude_path.read_bytes()
    existing = read_pulses(original_amplitudes)
    circuit = load_circuit(source)
    if not circuit.server:
        raise ValueError('Conversion expects a field task with positive pulse/coil indices')
    if circuit.floating and circuit.n < 2:
        raise ValueError('A floating circuit needs at least two branches')
    if any(len(w['times']) < 2 for w in circuit.waveforms):
        raise ValueError('Every phase requires an existing valid EMF waveform; no zero fallback is allowed')
    if any(b['pulse'] > len(existing) for b in circuit.branches):
        raise ValueError('Server AMP index exceeds the existing pulse bank')
    ident = model_id(circuit.phases, circuit.parallel, circuit.floating)
    descriptor = dict(schema='clark-om-client/1', model=ident, version=version,
                      dataFile='circuit-config.json', couplingFile='server-config.json')
    data = dict(schema='clark-circuit/2', phases=circuit.phases, parallel=circuit.parallel,
                floatingNeutral=circuit.floating,
                acceptanceTolerance=circuit.tolerance, integrationTolerance=min(1e-10, circuit.tolerance*.01),
                branches=[dict(L_H=b['L'], R_Ohm=b['R']) for b in circuit.branches],
                emf=[dict(pulse=len(existing)+k+1, amplitude=circuit.amplitude)
                     for k in range(circuit.phases)])
    pulses = [b['pulse'] for b in circuit.branches]
    coils = [b['coil'] for b in circuit.branches]
    coupling = dict(schema='clark-server/1', inputs=[dict(kind='AMP', indices=pulses)],
                    outputs=[dict(kind='PSI', indices=coils), dict(kind='RSP', indices=pulses)])
    additions = [dict(impuls=w['times']+w['values'], n=len(w['times'])) for w in circuit.waveforms]
    tail = ''.join(json.dumps(p, ensure_ascii=False, allow_nan=False, separators=(',', ':'))+'\n'
                   for p in additions).encode('utf-8')
    separator = b'' if not original_amplitudes or original_amplitudes.endswith((b'\n', b'\r')) else b'\n'
    updated_amplitudes = original_amplitudes + separator + tail
    # Stage every payload first. Publish the bank last with one replacement;
    # rollback removes only files created by this operation on any failure.
    created = []
    with tempfile.TemporaryDirectory(prefix='.prepare-om-', dir=inputs) as temporary:
        staged = Path(temporary)
        for path, value in zip(targets, (descriptor, data, coupling)):
            write_new(staged/path.name, value)
        staged_bank = staged/'amplitudes.txt'
        staged_bank.write_bytes(updated_amplitudes)
        try:
            for path in targets:
                with path.open('xb') as stream:
                    created.append(path)
                    stream.write((staged/path.name).read_bytes())
            if amplitude_path.read_bytes() != original_amplitudes:
                raise RuntimeError('amplitudes.txt changed during preparation; retry after closing its editor')
            os.replace(staged_bank, amplitude_path)
        except BaseException:
            for path in created:
                path.unlink()
            raise
    print(f'Model: {ident} / {version}')
    for path in targets:
        print(path)
    print(f'{amplitude_path}: appended pulses {len(existing)+1}..{len(existing)+circuit.phases}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--version', default='1.1.0')
    args = parser.parse_args()
    prepare(args.source, args.version)


if __name__ == '__main__':
    main()
