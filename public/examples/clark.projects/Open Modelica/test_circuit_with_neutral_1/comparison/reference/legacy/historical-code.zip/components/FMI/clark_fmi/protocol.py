"""Clark coupling v1: the same state machine for direct files and ZeroMQ."""
import json
import math
import uuid

VERSION = 'clark-coupling/1'
MAX_MESSAGE = 8 * 1024 * 1024


def encode(value):
    raw = json.dumps(value, allow_nan=False, separators=(',', ':')).encode('utf-8')
    if len(raw) > MAX_MESSAGE:
        raise ValueError('Message exceeds 8 MiB; negotiate a bulk format before expanding channels')
    return raw


def decode(raw):
    if len(raw) > MAX_MESSAGE:
        raise ValueError('Message exceeds 8 MiB')
    def invalid(value):
        raise ValueError(f'Non-JSON number: {value}')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f'Duplicate JSON key: {key}')
            result[key] = value
        return result
    value = json.loads(raw, parse_constant=invalid, object_pairs_hook=unique)
    encode(value)  # Also rejects overflow such as 1e999.
    if not isinstance(value, dict):
        raise ValueError('Expected a JSON object')
    return value


def number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{name}: expected a finite JSON number')
    return float(value)


def indices(values, name):
    if not isinstance(values, list) or not values or any(
            type(v) is not int or not 0 < v < 2**31 for v in values):
        raise ValueError(f'{name}: expected positive Int32 indices')
    return values


def vector(value, n, name):
    if not isinstance(value, list) or len(value) != n:
        raise ValueError(f'{name}: expected {n} values')
    return [number(v, name) for v in value]


def grid(value):
    dt = number(value['dt'], 'DTK')
    steps = value['steps']
    if dt <= 0 or type(steps) is not int or steps < 0 or not math.isfinite(dt * steps):
        raise ValueError('Invalid fixed time grid')
    if any(type(value[k]) is not int for k in ('d7', 'd9')):
        raise ValueError('D7 and D9 must be integers')
    return dict(dt=dt, steps=steps, d7=value['d7'], d9=value['d9'])


class Session:
    """One owner, no retries, no rollback, one immutable grid, one accept per step.

    An adapter exception poisons this session: the last request may have executed.
    Validation errors before adapter I/O are rejected without changing its state.
    """
    def __init__(self, adapter):
        self.adapter = adapter
        self.owner = None
        self.last_id = 0
        self.step = 0
        self.failed = False
        self.finished = False

    def handle(self, message):
        request = decode(encode(message))
        if request.get('version') != VERSION:
            raise ValueError('Unsupported protocol version')
        owner = request.get('session')
        if not isinstance(owner, str) or len(owner) != 32:
            raise ValueError('Session must be a UUID hex string')
        try:
            uuid.UUID(hex=owner)
        except ValueError as error:
            raise ValueError('Invalid session UUID') from error
        rid = request.get('id')
        if type(rid) is not int or not 0 < rid < 2**31 or rid != self.last_id + 1:
            raise ValueError('Request id must increase by one, starting at 1; retries are forbidden')
        if self.failed or self.finished:
            raise RuntimeError('Session is failed or finished; start a fresh solver task')
        if self.owner is not None and owner != self.owner:
            raise ValueError('Another client owns this solver session')
        op = request.get('op')
        fields = {'initialize': {'pulses', 'coils'},
                  'evaluate': {'step', 'time', 'current', 'accept'}, 'finish': set()}
        if op not in fields or set(request) - ({'version', 'session', 'id', 'op'} | fields[op]):
            raise ValueError('Unsupported operation or fields; negotiate an explicit protocol extension')
        if self.owner is None:
            if op != 'initialize':
                raise ValueError('Initialize first')
            pulses = indices(request.get('pulses'), 'pulses')
            coils = indices(request.get('coils'), 'coils')
            if len(pulses) != len(coils):
                raise ValueError('Pulse and coil counts must match')
            self.n = len(pulses)
            def action():
                self.grid = grid(self.adapter.initialize(pulses, coils))
                self.owner = owner
                return dict(grid=self.grid, channels=[
                    dict(name='current', direction='input', dtype='float64', unit='A', shape=[self.n]),
                    dict(name='flux', direction='output', dtype='float64', unit='Wb', shape=[self.n]),
                    dict(name='resistance', direction='output', dtype='float64', unit='Ohm', shape=[self.n])],
                    capabilities=dict(fixed_step=True, rollback=False, retry=False,
                                      history_commit_ack=False, motion=False),
                    backend='legacy-files')
        elif op == 'evaluate':
            if type(request.get('step')) is not int or request['step'] != self.step or self.step > self.grid['steps']:
                raise ValueError('Unexpected time step')
            expected = self.step * self.grid['dt']
            # JSON round-trips binary64 exactly: do not accept off-grid trial times.
            if number(request.get('time'), 'time') != expected:
                raise ValueError('Time must equal step * negotiated DTK')
            accept = request.get('accept')
            if type(accept) is not bool:
                raise ValueError('accept must be Boolean')
            current = vector(request.get('current'), self.n, 'current')
            def action():
                flux, resistance = self.adapter.evaluate(rid, current, accept)
                response = dict(flux=vector(list(flux), self.n, 'flux'),
                                resistance=vector(list(resistance), self.n, 'resistance'),
                                step=self.step, time=expected, accept_requested=accept,
                                history_committed=None)
                if accept:
                    self.step += 1
                return response
        elif op == 'finish':
            if self.step != self.grid['steps'] + 1:
                raise ValueError('Cannot finish before all endpoints, including t=0, have been accepted')
            def action():
                self.finished = True
                return dict(endpoints=self.step, history_committed=None)
        else:
            raise ValueError('Unsupported operation')
        self.last_id = rid
        try:
            result = action()
        except Exception:
            self.failed = True
            raise
        return dict(version=VERSION, session=owner, id=rid, ok=True, result=result)


class Client:
    def __init__(self, transport, pulses, coils):
        self.transport = transport
        self.session = uuid.uuid4().hex
        self.id = 0
        self.failed = False
        result = self.call('initialize', pulses=pulses, coils=coils)
        self.grid = grid(result['grid'])
        self.description = result

    def call(self, op, **values):
        if self.failed:
            raise RuntimeError('Failed client cannot retry requests')
        self.id += 1
        request = dict(version=VERSION, session=self.session, id=self.id, op=op, **values)
        try:
            response = self.transport.request(request)
            if any(response.get(k) != request[k] for k in ('version', 'session', 'id')):
                raise ValueError('Response identity mismatch')
            if response.get('ok') is not True:
                raise RuntimeError(response.get('error', 'Remote error'))
            return response['result']
        except Exception:
            self.failed = True
            raise

    def evaluate(self, step, current, accept=False):
        response = self.call('evaluate', step=step, time=step*self.grid['dt'],
                             current=list(map(float, current)), accept=accept)
        n = len(current)
        return vector(response['flux'], n, 'flux'), vector(response['resistance'], n, 'resistance')

    def finish(self):
        return self.call('finish')
