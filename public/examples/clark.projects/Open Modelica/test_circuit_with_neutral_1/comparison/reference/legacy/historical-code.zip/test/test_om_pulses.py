"""Task pulse preparation and native package contracts; no OM/Julia required."""
import contextlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import warnings

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'components/FMI'))
from clark_om import prepare as preparation
from clark_om.build import make_descriptor, make_editor_preset


class OMPulseTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.inputs = self.root/'input3XX'
        self.inputs.mkdir()
        record = dict(impuls=[0, 0.25, 0.5, 4, -2, 7], n=3)
        self.original_bank = ('\ufeff'+'\r\n'.join(json.dumps(record) for _ in range(7))).encode('utf-8')
        (self.inputs/'amplitudes.txt').write_bytes(self.original_bank)
        (self.inputs/'general.txt').write_text('{"timeStep":0.025,"countTimeSteps":20}\n')
        (self.inputs/'kvs.txt').write_text('original geometry\n')
        self.waveforms = [([0, 0.2, 0.5], [0.1*k, -k, k+0.5]) for k in (1, 2, 3)]
        for index, (times, values) in enumerate(self.waveforms, 1):
            (self.root/f'{index}.txt').write_text('3\n'+''.join(f'{t} {v}\n' for t, v in zip(times, values)))
        (self.root/'circuit-config.txt').write_text(
            'reference circuit\n3 1\n1.txt\n1 1 100 1\n2.txt\n2 2 100 1\n3.txt\n3 3 100 1\n'
            '0\n100\n0\n1\n10\n')

    def prepare(self):
        with contextlib.redirect_stdout(io.StringIO()):
            preparation.prepare(self.root)
        return [json.loads((self.inputs/name).read_text()) for name in
                ('om-client.json', 'circuit-config.json', 'server-config.json')]

    def snapshot(self):
        return {p.relative_to(self.root).as_posix(): p.read_bytes()
                for p in self.root.rglob('*') if p.is_file()}

    def test_exact_waveforms_append_without_modifying_original_inputs(self):
        before = self.snapshot()
        selection, data, coupling = self.prepare()
        self.assertEqual(selection['version'], '1.1.0')
        self.assertEqual(selection['model'], 'circuit-p3-b1-grounded')
        self.assertEqual(data['schema'], 'clark-circuit/2')
        self.assertNotIn('amplitude', data)
        self.assertEqual(data['emf'], [dict(pulse=k, amplitude=100) for k in (8, 9, 10)])
        self.assertEqual(data['branches'], [dict(L_H=100, R_Ohm=1)]*3)
        self.assertEqual(data['acceptanceTolerance'], 1)
        self.assertEqual(data['integrationTolerance'], 1e-10)
        self.assertEqual(coupling['inputs'], [dict(kind='AMP', indices=[1, 2, 3])])
        self.assertEqual(coupling['outputs'], [dict(kind='PSI', indices=[1, 2, 3]), dict(kind='RSP', indices=[1, 2, 3])])
        raw = (self.inputs/'amplitudes.txt').read_bytes()
        self.assertTrue(raw.startswith(self.original_bank))
        records = preparation.read_pulses(raw)
        self.assertEqual(len(records), 10)
        self.assertEqual(records[:7], preparation.read_pulses(self.original_bank))
        for k, (times, values) in enumerate(self.waveforms):
            self.assertEqual(records[k+7], dict(n=3, impuls=times+values))
            self.assertEqual([v*data['emf'][k]['amplitude'] for v in records[k+7]['impuls'][3:]],
                             [v*100 for v in values])
        for path, content in before.items():
            if path != 'input3XX/amplitudes.txt':
                self.assertEqual((self.root/path).read_bytes(), content, path)

    def test_repeated_preparation_never_overwrites(self):
        self.prepare()
        before = self.snapshot()
        with self.assertRaises(FileExistsError):
            self.prepare()
        self.assertEqual(before, self.snapshot())

    def test_missing_waveform_fails_without_any_writes(self):
        (self.root/'2.txt').unlink()
        before = self.snapshot()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with self.assertRaisesRegex(ValueError, 'waveform'):
                self.prepare()
        self.assertEqual(before, self.snapshot())

    def test_failure_to_replace_bank_rolls_back_new_json(self):
        before = self.snapshot()
        with mock.patch.object(preparation.os, 'replace', side_effect=OSError('replace failed')):
            with self.assertRaisesRegex(OSError, 'replace failed'):
                self.prepare()
        self.assertEqual(before, self.snapshot())
        self.assertEqual(sorted(p.name for p in self.inputs.iterdir()), ['amplitudes.txt', 'general.txt', 'kvs.txt'])

    def test_staging_failure_has_no_published_changes(self):
        before = self.snapshot()
        original = preparation.write_new
        def fail_second(path, value):
            if path.name == 'circuit-config.json':
                raise OSError('staging failed')
            original(path, value)
        with mock.patch.object(preparation, 'write_new', side_effect=fail_second):
            with self.assertRaisesRegex(OSError, 'staging failed'):
                self.prepare()
        self.assertEqual(before, self.snapshot())

    def test_concurrent_bank_edit_is_preserved_and_new_json_rolled_back(self):
        original = preparation.write_new
        changed = self.original_bank+b'\n'+b'{"n":2,"impuls":[0,1,5,5]}\n'
        def edit_bank(path, value):
            original(path, value)
            if path.name == 'server-config.json':
                (self.inputs/'amplitudes.txt').write_bytes(changed)
        with mock.patch.object(preparation, 'write_new', side_effect=edit_bank):
            with self.assertRaisesRegex(RuntimeError, 'changed during preparation'):
                self.prepare()
        self.assertEqual((self.inputs/'amplitudes.txt').read_bytes(), changed)
        self.assertFalse((self.inputs/'om-client.json').exists())

    def test_invalid_existing_bank_is_rejected_without_writes(self):
        invalid = [dict(n=True, impuls=[0, 1, 1, 1]), dict(n=1, impuls=[0, 1]),
                   dict(n=2, impuls=[0, 1, 1]), dict(n=2, impuls=[0, 0, 1, 1]),
                   dict(n=2, impuls=[1, 0, 1, 1]), dict(n=2, impuls=[0, 1, True, 1]),
                   dict(n=2, impuls=[0, 1, float('inf'), 1]), dict(n=2, impuls=[0, 1, 1, '1'])]
        for value in invalid:
            with self.subTest(value=value):
                (self.inputs/'amplitudes.txt').write_text(json.dumps(value)+'\n')
                before = self.snapshot()
                with self.assertRaises(ValueError):
                    self.prepare()
                self.assertEqual(before, self.snapshot())

    def test_pulse_parser_rejects_blank_and_duplicate_records(self):
        for raw in [b'\n', b'{"n":2,"n":2,"impuls":[0,1,0,1]}\n']:
            with self.assertRaises(ValueError):
                preparation.read_pulses(raw)

    def test_descriptor_uses_pulses_and_rejects_legacy_data(self):
        selection, data, coupling = self.prepare()
        package = self.root/'package'
        package.mkdir()
        (package/'client.exe').write_bytes(b'stub')
        descriptor = make_descriptor(selection, data, '1.27.1', 'runtime-hash', package)
        self.assertEqual(descriptor['dataSchema'], 'clark-circuit/2')
        self.assertNotIn('amplitude', descriptor['runtimeParameters'])
        self.assertNotIn('amplitude', [item['parameter'] for item in descriptor['parameterBindings']])
        self.assertEqual(descriptor['tables'], [dict(name=f'emf{k+1}', source='task-pulse',
            pulsePath=['emf', k, 'pulse'], scalePath=['emf', k, 'amplitude']) for k in range(3)])
        preset = make_editor_preset(selection, data, coupling, descriptor)
        self.assertEqual(preset['contract']['tables'], descriptor['tables'])
        self.assertEqual(preset['data'], data)
        legacy_data = dict(data, schema='clark-circuit/1', amplitude=100,
            emf=[dict(points=list(map(list, zip(times, values)))) for times, values in self.waveforms])
        with self.assertRaisesRegex(ValueError, 'clark-circuit/2'):
            make_descriptor(selection, legacy_data, '1.27.1', 'runtime-hash', package)


if __name__ == '__main__':
    unittest.main()
