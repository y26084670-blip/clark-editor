"""Fixed-grid nonlinear coordinator. Trials never advance the field history."""
import numpy as np
from .protocol import grid as validate_grid


def solve(circuit, grid, model, field=None, on_step=None, trace=None, max_iterations=1000):
    grid = validate_grid(grid)
    n = circuit.n
    symmetry = (2 if grid['d7'] >= 0 else 1)*(2 if grid['d9'] >= 0 else 1)
    previous = dict(current=np.zeros(n), flux=np.zeros(n), field_voltage=np.zeros(n),
                    emf=np.zeros(circuit.phases), neutral=0.0)
    x = np.zeros(n+int(circuit.floating))
    increments = np.full(len(x), circuit.increment)
    if circuit.floating:
        increments[-1] = 10*circuit.tolerance
    snapshots = []
    for step in range(grid['steps']+1):
        time = step * grid['dt']  # Never accumulate time or adjust DTK.
        emf = np.zeros(circuit.phases) if step == 0 else circuit.emf(time)
        evaluations = 0

        def evaluate(trial, accept=False):
            nonlocal evaluations
            if not np.all(np.isfinite(trial)):
                raise ValueError('Non-finite circuit iterate')
            flux, resistance = field.evaluate(step, trial[:n], accept) if field else (np.zeros(n), np.zeros(n))
            flux, resistance = np.asarray(flux), np.asarray(resistance)
            if flux.shape != (n,) or resistance.shape != (n,) or not (
                    np.all(np.isfinite(flux)) and np.all(np.isfinite(resistance))):
                raise ValueError('Invalid field output')
            f = model.evaluate(time, trial[:n], flux, resistance, emf, previous,
                               float(trial[-1]) if circuit.floating else 0.0)
            evaluations += 1
            if trace:
                trace(dict(step=step, time=time, evaluation=evaluations, accept=accept,
                           x=trial.tolist(), residual=f.tolist(), norm=float(np.linalg.norm(f))))
            return f, flux, resistance

        if step > 0:
            f, _, _ = evaluate(x)
            for iteration in range(max_iterations):
                norm = np.linalg.norm(f)
                if norm <= circuit.tolerance:
                    break
                jacobian = np.empty((len(x), len(x)))
                for j, increment in enumerate(increments):
                    trial = x.copy()
                    trial[j] += increment
                    if trial[j] == x[j]:
                        raise RuntimeError('Finite-difference increment is too small for the current magnitude')
                    changed, _, _ = evaluate(trial)
                    jacobian[:, j] = (changed-f)/(trial[j]-x[j])
                try:
                    delta = np.linalg.solve(jacobian, -f)
                except np.linalg.LinAlgError as error:
                    raise RuntimeError(f'Step {step}: singular circuit Jacobian; DTK unchanged') from error
                # Damping changes the nonlinear iterate, never the physical time step.
                for exponent in range(13):
                    trial = x + delta*(.5**exponent)
                    changed, _, _ = evaluate(trial)
                    if np.linalg.norm(changed) < norm:
                        x, f = trial, changed
                        break
                else:
                    raise RuntimeError(f'Step {step}: nonlinear iteration stalled; DTK unchanged')
            if np.linalg.norm(f) > circuit.tolerance:
                raise RuntimeError(f'Step {step}: no convergence in {max_iterations} iterations; DTK unchanged')
        # Even if the last trial was a perturbed Jacobian point, accept only the solution.
        f, flux, resistance = evaluate(x, accept=True)
        if step > 0 and np.linalg.norm(f) > circuit.tolerance:
            raise RuntimeError(f'Step {step}: final field response changed after acceptance; abort the session')
        neutral = float(x[-1]) if circuit.floating else 0.0
        snapshot = dict(step=step, time_s=time, status=0 if step == 0 else 1,
                        emf_V=emf.tolist(), current_A=x[:n].tolist(), flux_Wb=flux.tolist(),
                        field_resistance_Ohm=resistance.tolist(), neutral_V=neutral,
                        residual=f.tolist(), residual_norm=float(np.linalg.norm(f)), evaluations=evaluations)
        snapshots.append(snapshot)
        if on_step:
            on_step(snapshot)
        previous = dict(current=x[:n].copy(), flux=flux.copy(),
                        field_voltage=symmetry*resistance*x[:n], emf=emf.copy(), neutral=neutral)
    if field:
        field.finish()
    return snapshots
