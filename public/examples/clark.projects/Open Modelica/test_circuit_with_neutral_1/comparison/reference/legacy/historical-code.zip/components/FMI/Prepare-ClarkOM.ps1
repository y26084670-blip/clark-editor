﻿#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string] $Source, [string] $Version = '1.1.0', [string] $PythonExe)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'ClarkFMI.psm1') -Force -DisableNameChecking
if (-not $PythonExe) { $PythonExe = (Read-ClarkFMIJson (Join-Path $PSScriptRoot 'fmi-settings.json')).pythonExe }
$reports = Join-Path $PSScriptRoot 'runs'
[void] [IO.Directory]::CreateDirectory($reports)
$log = Join-Path $reports ('prepare-om-' + [guid]::NewGuid().ToString('N') + '.txt')
try {
    [void] (Invoke-ClarkFMIProcess -Executable $PythonExe -Arguments @('-m', 'clark_om.prepare', (Get-ClarkFMIPath $Source), '--version', $Version) -LogPath $log)
}
catch { Write-Error -ErrorRecord $_ -ErrorAction Continue; exit 1 }
