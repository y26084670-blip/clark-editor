﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string] $Source,
    [string] $RunDirectory,
    [ValidateSet('files', 'zmq')][string] $Transport = 'zmq',
    [ValidateRange(0, 2147483647)][int] $Processes = 0,
    [ValidateRange(1, 86400)][int] $StartupSeconds = 300,
    [ValidateRange(1, 86400)][int] $ResponseSeconds = 600,
    [ValidateRange(1, 86400)][int] $FinishSeconds = 30,
    [string] $SettingsPath
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 -File does not populate PSScriptRoot during parameter binding.
if (-not $PSBoundParameters.ContainsKey('SettingsPath')) {
    $SettingsPath = Join-Path $PSScriptRoot 'fmi-settings.json'
}
Import-Module (Join-Path $PSScriptRoot 'ClarkFMI.psm1') -Force -DisableNameChecking
$run = $null
try {
    $settings = Get-ClarkFMISettings $SettingsPath
    $run = New-ClarkFMIRun -Settings $settings -Kind 'run' -Source $Source -RunDirectory $RunDirectory
    $run.Record.options = @{ transport = $Transport; processes = $Processes;
        startup_seconds = $StartupSeconds; response_seconds = $ResponseSeconds; finish_seconds = $FinishSeconds }
    Write-ClarkFMIJson $run.Manifest $run.Record
    Save-ClarkFMIEnvironment $settings $run.Reports
    $case = Join-Path $run.Directory 'case'
    [void] (Invoke-ClarkFMIPython $settings @('-m', 'clark_fmi', 'prepare', $run.Record.source, $case) (Join-Path $run.Reports 'prepare.txt'))
    $result = Invoke-ClarkFMICase $settings $case $run.Reports 'run' $Transport $Processes $StartupSeconds $ResponseSeconds $FinishSeconds
    $run.Record.results = @($result)
    Save-ClarkFMIRun $run -Complete
    Write-Host "FMI run complete. Results: $($result.results)"
    Write-Host "Launch record: $($run.Manifest)"
    exit 0
}
catch {
    if ($null -ne $run) { Save-ClarkFMIRun $run -ErrorMessage $_.Exception.Message }
    Write-Error -ErrorRecord $_ -ErrorAction Continue
    exit 1
}
