﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [string] $AppRoot,
    [string] $OmcExe,
    [string] $PythonExe,
    [ValidatePattern('^3\.[0-9]+$')][string] $PythonVersion = '3.14',
    [string] $RunsDirectory,
    [string] $SettingsPath
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 -File does not populate PSScriptRoot during parameter binding.
if (-not $PSBoundParameters.ContainsKey('SettingsPath')) {
    $SettingsPath = Join-Path $PSScriptRoot 'fmi-settings.json'
}
Import-Module (Join-Path $PSScriptRoot 'ClarkFMI.psm1') -Force -DisableNameChecking
$run = $null
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Initialize-ClarkFMI.ps1 requires Windows x64.' }
    $settingsFile = Get-ClarkFMIPath $SettingsPath
    $old = if ([IO.File]::Exists($settingsFile)) { Read-ClarkFMIJson $settingsFile } else { $null }
    if ($null -ne $old -and $old.schema -ne 1) { throw 'Unsupported fmi-settings.json schema.' }
    if (-not $AppRoot -and $null -ne $old) { $AppRoot = $old.appRoot }
    if (-not $OmcExe -and $null -ne $old) { $OmcExe = $old.omcExe }
    if (-not $RunsDirectory) {
        $RunsDirectory = if ($null -ne $old) { $old.runsDirectory } else { Join-Path $PSScriptRoot 'runs' }
    }
    if (-not $AppRoot -or -not $OmcExe) { throw 'First initialization requires -AppRoot and -OmcExe.' }
    $AppRoot = Get-ClarkFMIPath $AppRoot
    $OmcExe = Get-ClarkFMIPath $OmcExe
    if (-not [IO.Directory]::Exists($AppRoot)) { throw "Installed Clark directory not found: '$AppRoot'." }
    if (-not [IO.File]::Exists($OmcExe)) { throw "OpenModelica not found: '$OmcExe'." }
    $venv = Join-Path $PSScriptRoot '.venv'
    $python = Join-Path $venv 'Scripts/python.exe'
    $settings = [pscustomobject] @{ schema = 1; appRoot = $AppRoot; omcExe = $OmcExe;
        pythonExe = $python; runsDirectory = (Get-ClarkFMIPath $RunsDirectory);
        requirements_sha256 = (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'requirements.txt') -Algorithm SHA256).Hash.ToLowerInvariant();
        updated_utc = [DateTime]::UtcNow.ToString('o') }
    $run = New-ClarkFMIRun -Settings $settings -Kind 'setup'
    if (-not [IO.File]::Exists($python)) {
        if ([IO.Directory]::Exists($venv)) { throw "Incomplete .venv at '$venv'; inspect it before creating a replacement." }
        if ($PythonExe) {
            $bootstrap = Get-ClarkFMIPath $PythonExe
            $arguments = @('-m', 'venv', $venv)
        }
        else {
            $bootstrap = (Get-Command py.exe -CommandType Application -ErrorAction Stop | Select-Object -First 1).Path
            $arguments = @("-$PythonVersion", '-m', 'venv', $venv)
        }
        [void] (Invoke-ClarkFMIProcess $bootstrap $arguments (Join-Path $run.Reports 'venv-create.txt'))
    }
    elseif ($PythonExe -or $PSBoundParameters.ContainsKey('PythonVersion')) {
        throw 'An existing .venv is reused. Omit -PythonExe/-PythonVersion; changing its interpreter requires a separately prepared environment.'
    }
    $probe = 'import struct,sys; print(sys.version); print(sys.executable); sys.exit(0 if sys.version_info >= (3,12) and struct.calcsize("P") == 8 else 1)'
    [void] (Invoke-ClarkFMIPython $settings @('-c', $probe) (Join-Path $run.Reports 'python-check.txt'))
    [void] (Invoke-ClarkFMIPython $settings @('-m', 'pip', 'install', '--disable-pip-version-check', '-r', (Join-Path $PSScriptRoot 'requirements.txt')) (Join-Path $run.Reports 'pip-install.txt'))
    [void] (Invoke-ClarkFMIPython $settings @('-m', 'pip', 'check') (Join-Path $run.Reports 'pip-check.txt'))
    [void] (Assert-ClarkFMIInstalled $settings)
    Save-ClarkFMIEnvironment $settings $run.Reports
    Write-ClarkFMIJson $settingsFile $settings
    Save-ClarkFMIRun $run -Complete
    Write-Host "FMI environment ready. Settings: $settingsFile"
    Write-Host "Reports: $($run.Reports)"
    exit 0
}
catch {
    if ($null -ne $run) { Save-ClarkFMIRun $run -ErrorMessage $_.Exception.Message }
    Write-Error -ErrorRecord $_ -ErrorAction Continue
    exit 1
}
