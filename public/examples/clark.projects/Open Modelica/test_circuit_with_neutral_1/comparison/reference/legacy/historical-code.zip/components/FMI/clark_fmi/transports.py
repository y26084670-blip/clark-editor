"""Legacy-file adapter and loopback ZeroMQ transport; no code inside MPI loops."""
import math
from pathlib import Path
import queue
import re
import socket as network_socket
import sys
import struct
import threading
import time

from .configuration import finite, integer
from .protocol import MAX_MESSAGE, Session, decode, encode


def positive_timeout(value):
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError('Timeout must be positive and finite')
    return value


class LegacyFiles:
    def __init__(self, directory, timeout=600):
        self.root = Path(directory).resolve()
        if not self.root.is_dir():
            raise ValueError('Task directory does not exist')
        self.timeout = positive_timeout(timeout)
        self.stop = threading.Event()

    def absent(self, *names):
        for name in names:
            if (self.root/name).exists():
                raise FileExistsError(f'Pending file exists: {self.root/name}')

    def publish(self, name, data):
        self.absent(name, name+'.allow')
        # Exclusive creation; the server cannot read until the closed payload's marker appears.
        with (self.root/name).open('xb') as stream:
            stream.write(data)
        (self.root/(name+'.allow')).touch(exist_ok=False)

    def wait(self, name):
        marker = self.root/(name+'.allow')
        end = time.monotonic() + self.timeout
        while not marker.is_file():
            if marker.exists():
                raise ValueError(f'Marker is not a file: {marker}')
            if self.stop.is_set():
                raise InterruptedError('Bridge is stopping')
            remaining = end - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(f'No reply after {self.timeout}s: {marker}; request NOT retried')
            self.stop.wait(min(.025, remaining))
        return marker

    def initialize(self, pulses, coils):
        self.n = len(pulses)
        self.absent('server-dialog2.txt', 'server-dialog2.txt.allow')
        self.publish('server-dialog1.txt', b'D7\nD9\nNDTK\nDTK\n')
        marker = self.wait('server-dialog2.txt')
        values = (self.root/'server-dialog2.txt').read_text(encoding='ascii').split()
        if len(values) != 4:
            raise ValueError('Expected four server parameter values')
        result = dict(d7=integer(values[0], 'D7'), d9=integer(values[1], 'D9'),
                      steps=integer(values[2], 'NDTK', 0), dt=finite(values[3], 'DTK'))
        from .protocol import grid
        result = grid(result)
        marker.unlink()
        # AMP(pulses); PSI(coils); RSP(pulses). Group order matches CircuitClient.
        rows = [1, 1, self.n, ' '.join(map(str, pulses)),
                2, 1, self.n, ' '.join(map(str, coils)),
                2, self.n, ' '.join(map(str, pulses))]
        self.publish('server-config.txt', ('\n'.join(map(str, rows))+'\n').encode('ascii'))
        return result

    def evaluate(self, request_id, current, accept):
        self.absent('server-inp.bin', 'server-inp.bin.allow',
                    'server-out.bin', 'server-out.bin.allow', 'server-nexttime_allow')
        payload = struct.pack('<i'+'d'*self.n, request_id, *current)
        if accept:
            # Required BEFORE the final request, including t=0. Never repeat on timeout.
            (self.root/'server-nexttime_allow').touch(exist_ok=False)
        self.publish('server-inp.bin', payload)
        marker = self.wait('server-out.bin')
        path = self.root/'server-out.bin'
        data = path.read_bytes()
        if len(data) != 4+16*self.n:
            raise ValueError('Incorrect binary response length; files retained for diagnosis')
        values = struct.unpack('<i'+'d'*(2*self.n), data)
        if values[0] != request_id or not all(math.isfinite(v) for v in values[1:]):
            raise ValueError('Invalid binary response id or values; files retained for diagnosis')
        marker.unlink()
        path.unlink()
        # The old protocol returns mWb. Normalize exactly once at this boundary.
        return [v*.001 for v in values[1:self.n+1]], list(values[self.n+1:])


class DirectTransport:
    def __init__(self, session):
        self.session = session

    def request(self, value):
        return decode(encode(self.session.handle(decode(encode(value)))))

    def close(self):
        self.session.adapter.stop.set()


def loopback_endpoint(endpoint):
    if not re.fullmatch(r'tcp://127\.0\.0\.1:([1-9][0-9]{0,4})', endpoint):
        raise ValueError('Prototype endpoints must be tcp://127.0.0.1:PORT')
    if int(endpoint.rsplit(':', 1)[1]) > 65535:
        raise ValueError('Invalid TCP port')
    return endpoint


def tcp_bind_preflight():
    # libzmq 4.3.5 aborts in getifaddrs() when a Linux sandbox denies interface
    # enumeration. Diagnose before entering native code; do not retry or bypass it.
    if sys.platform.startswith('linux'):
        try:
            network_socket.if_nameindex()
        except PermissionError as error:
            raise RuntimeError('This environment denies network-interface enumeration required by libzmq; '
                               'run TCP tests locally or explicitly select --transport files') from error


class ZmqTransport:
    def __init__(self, endpoint, timeout=610):
        import zmq
        endpoint = loopback_endpoint(endpoint)
        timeout = positive_timeout(timeout)
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REQ)
        self.socket.setsockopt(zmq.LINGER, 0)
        self.socket.setsockopt(zmq.MAXMSGSIZE, MAX_MESSAGE)
        self.socket.setsockopt(zmq.SNDTIMEO, int(positive_timeout(timeout)*1000))
        self.socket.setsockopt(zmq.RCVTIMEO, int(timeout*1000))
        self.socket.connect(loopback_endpoint(endpoint))
        self.failed = False

    def request(self, value):
        import zmq
        if self.failed:
            raise RuntimeError('Timed-out ZeroMQ socket must not retry')
        try:
            self.socket.send(encode(value))
            return decode(self.socket.recv())
        except zmq.Again as error:
            self.failed = True
            raise TimeoutError('ZeroMQ reply timed out; request may have executed; NOT retried') from error
        except Exception:
            self.failed = True
            raise

    def close(self):
        self.socket.close(linger=0)
        self.context.term()


class Bridge:
    """Own the REP socket on one thread. The MPI server remains a separate process."""
    def __init__(self, adapter, endpoint=None):
        self.adapter = adapter
        self.endpoint = loopback_endpoint(endpoint) if endpoint else None
        self.stop = threading.Event()
        self.ready = queue.Queue()
        self.error = None
        self.thread = threading.Thread(target=self.serve, name='clark-fmi-bridge', daemon=True)

    def start(self):
        tcp_bind_preflight()
        self.thread.start()
        outcome = self.ready.get(timeout=10)
        if isinstance(outcome, Exception):
            self.thread.join(timeout=2)
            raise outcome
        self.endpoint = outcome
        return self

    def serve(self):
        import zmq
        context = zmq.Context()
        socket = context.socket(zmq.REP)
        socket.setsockopt(zmq.LINGER, 0)
        socket.setsockopt(zmq.MAXMSGSIZE, MAX_MESSAGE)
        socket.setsockopt(zmq.SNDTIMEO, 1000)
        session = Session(self.adapter)
        announced = False
        try:
            if self.endpoint:
                socket.bind(self.endpoint)
                endpoint = self.endpoint
            else:
                port = socket.bind_to_random_port('tcp://127.0.0.1')
                endpoint = f'tcp://127.0.0.1:{port}'
            self.ready.put(endpoint)
            announced = True
            while not self.stop.is_set():
                if not socket.poll(50):
                    continue
                request = {}
                try:
                    request = decode(socket.recv())
                    response = session.handle(request)
                except Exception as error:
                    response = {k: request.get(k) for k in ('version', 'session', 'id')}
                    response.update(ok=False, error=f'{type(error).__name__}: {error}')
                socket.send(encode(response))
                if session.finished or session.failed:
                    break
        except Exception as error:
            self.error = error
            if not announced:
                self.ready.put(error)
        finally:
            # Let the final finish/error reply leave the queue before terminating REP.
            socket.close(linger=1000)
            context.term()

    def close(self):
        self.stop.set()
        self.adapter.stop.set()
        self.thread.join(timeout=5)
        if self.thread.is_alive():
            raise RuntimeError('Bridge did not stop within 5 seconds')
