"""Read CircuitClient's current list-directed format without modifying the task."""
from dataclasses import asdict, dataclass
import math
from pathlib import Path
import warnings


def finite(value, name):
    if isinstance(value, bool):
        raise ValueError(f"{name}: Boolean is not a number")
    result = float(str(value).replace("D", "E").replace("d", "e"))
    if not math.isfinite(result):
        raise ValueError(f"{name}: expected a finite number")
    return result


def integer(value, name, minimum=None):
    if isinstance(value, bool):
        raise ValueError(f"{name}: Boolean is not an integer")
    result = int(str(value))
    if minimum is not None and result < minimum:
        raise ValueError(f"{name}: minimum {minimum}")
    return result


def text_file(path):
    data = Path(path).read_bytes()
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        warnings.warn(f"{path}: reading legacy Windows-1251", stacklevel=2)
        return data.decode("cp1251")


def tokens(line, limit=None):
    result, current, quote, active = [], [], None, False
    i = 0
    while i < len(line):
        c = line[i]
        if quote:
            if c == quote:
                if i+1 < len(line) and line[i+1] == quote:
                    current.append(c)
                    i += 1
                else:
                    quote = None
            else:
                current.append(c)
        elif c in "!#":
            break
        elif c in "\"'":
            quote, active = c, True
        elif c.isspace() or c == ',':
            if active:
                result.append(''.join(current))
                current, active = [], False
                if len(result) == limit:
                    return result
        else:
            current.append(c)
            active = True
        i += 1
    if quote:
        raise ValueError("Unterminated quoted value")
    if active:
        result.append(''.join(current))
    return result


class Records:
    def __init__(self, lines, position=0):
        self.lines, self.position = lines, position

    def read(self, count=1):
        while self.position < len(self.lines):
            line = self.lines[self.position]
            self.position += 1
            values = tokens(line, count)
            if values:
                if len(values) < count:
                    raise ValueError(f"Line {self.position}: expected {count} fields")
                return values
        raise ValueError("Unexpected end of circuit data")


@dataclass
class Circuit:
    phases: int
    parallel: int
    branches: list
    waveforms: list
    floating: bool
    amplitude: float
    material: int
    tolerance: float
    increment: float
    local_grid: dict | None

    @property
    def n(self):
        return len(self.branches)

    @property
    def server(self):
        return any(b['pulse'] > 0 for b in self.branches)

    def to_dict(self):
        return asdict(self)

    def emf(self, time):
        import numpy as np
        return np.array([self.amplitude * np.interp(time, w['times'], w['values'])
                         if w['times'] else 0.0 for w in self.waveforms])


def load_waveform(path):
    # Match Julia's explicit zero fallback, but make it visible in preparation logs.
    try:
        records = Records(text_file(path).splitlines())
        count = integer(records.read()[0], "waveform nodes", 2)
        if count > len(records.lines)-records.position:
            raise ValueError("Missing waveform nodes")
        points = [[finite(v, "waveform") for v in records.read(2)] for _ in range(count)]
        if any(b[0] <= a[0] for a, b in zip(points, points[1:])):
            raise ValueError("Waveform times must increase")
        return {'times': [p[0] for p in points], 'values': [p[1] for p in points]}
    except (OSError, ValueError, UnicodeError) as error:
        warnings.warn(f"{path}: zero EMF as in CircuitClient ({error})", stacklevel=2)
        return {'times': [], 'values': []}


def load_circuit(directory):
    root = Path(directory).resolve()
    lines = text_file(root/'circuit-config.txt').splitlines()
    records = Records(lines, 1)  # First physical line is the descriptive header.
    try:
        n, m = [integer(v, "circuit dimensions", 1) for v in records.read(2)]
    except ValueError as error:
        raise ValueError("Expected current CircuitClient format: N M, waveform line, "
                         "then M rows (pulse coil L R). Old 204 one-line branches "
                         "require explicit conversion in a copy of the task.") from error
    if n*(m+1) > len(lines):
        raise ValueError("Circuit dimensions exceed available records")
    branches, waveforms = [], []
    for _ in range(n):
        name = records.read()[0].replace('\\', '/')
        waveforms.append(load_waveform(root/name))
        for _ in range(m):
            p, c, l, r = records.read(4)
            branches.append(dict(pulse=integer(p, "pulse"), coil=integer(c, "coil"),
                                 L=finite(l, "L"), R=finite(r, "R")))
    connection = integer(records.read()[0], "connection")
    amplitude = finite(records.read()[0], "amplitude")
    material = integer(records.read()[0], "material")
    tolerance = finite(records.read()[0], "tolerance")
    increment = finite(records.read()[0], "increment")
    if connection not in (0, 1) or material not in (0, 1) or min(tolerance, increment) <= 0:
        raise ValueError("Invalid connection, material, tolerance or increment")
    server = any(b['pulse'] > 0 for b in branches)
    if server and not all(0 < b[k] < 2**31 for b in branches for k in ('pulse', 'coil')):
        raise ValueError("All server branch indices must be positive Int32")
    grid = None
    if not server:
        records.position += 1  # Exactly one comment record, like Julia.
        dt = finite(records.read()[0], "DTK")
        steps = integer(records.read()[0], "NDTK", 0)
        if dt <= 0:
            raise ValueError("DTK must be positive")
        grid = dict(dt=dt, steps=steps, d7=-1, d9=-1)
    return Circuit(n, m, branches, waveforms, bool(connection), amplitude,
                   material, tolerance, increment, grid)
