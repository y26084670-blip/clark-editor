﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string] $CaseDirectory,
    [Parameter(Mandatory = $true)][string] $AppRoot,
    [string] $PythonExe,
    [ValidateSet('files', 'zmq')][string] $Transport = 'zmq',
    [ValidateRange(0, 2147483647)][int] $Processes = 0,
    [ValidateRange(1, 86400)][int] $StartupSeconds = 300,
    [ValidateRange(1, 86400)][int] $ResponseSeconds = 600,
    [ValidateRange(1, 86400)][int] $FinishSeconds = 30
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 -File does not populate PSScriptRoot during parameter binding.
if (-not $PSBoundParameters.ContainsKey('PythonExe')) {
    $PythonExe = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
}
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
# Reuse the existing Windows job-object owner and ready-handshake implementation.
# Parameter names above intentionally differ from the dot-sourced script's parameters.
$componentDirectory = $PSScriptRoot
$helper = Join-Path $componentDirectory '..\..\deployment\commands\Invoke-ClarkCircuit.ps1'
. $helper

$job = $null; $server = $null; $client = $null; $caseLock = $null
$listLock = $null; $sessionDirectory = $null
try {
    $case = [IO.Path]::GetFullPath($CaseDirectory)
    $application = [IO.Path]::GetFullPath($AppRoot)
    $python = [IO.Path]::GetFullPath($PythonExe)
    if (-not [IO.File]::Exists((Join-Path $case 'fmi-case.json'))) { throw 'Сначала выполните prepare и build для новой копии задачи.' }
    if (-not [IO.File]::Exists((Join-Path $case 'circuit.fmu'))) { throw 'Не найдена FMU; выполните build.' }
    if ([IO.Directory]::Exists((Join-Path $case 'fmi-results'))) { throw 'Каталог уже запускался; подготовьте новую копию задачи.' }
    Assert-ClarkCircuitTask -TaskDirectory $case
    Assert-ClarkCircuitExecutablePath -Path $python
    $runtime = Get-ClarkCircuitRuntime -ApplicationRoot $application
    if ($Processes -gt 0) { $runtime.MpiRanks = $Processes }
    $solver = Join-Path $application 'runtime\bin\clark3XX64.exe'
    Assert-ClarkCircuitExecutablePath -Path $solver
    # Keep the lock file after releasing the handle, as the shared Julia launcher does.
    $caseLock = [IO.File]::Open((Join-Path $case '.clark-circuit.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    $sessionDirectory = Join-Path ([IO.Path]::GetTempPath()) ('clark-fmi-' + [guid]::NewGuid().ToString('N'))
    [void] [IO.Directory]::CreateDirectory($sessionDirectory)
    $list = Join-Path $sessionDirectory 'tasks.txt'
    $ready = Join-Path $sessionDirectory 'ready.txt'
    [IO.File]::WriteAllText($list, $case + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
    $listLock = [IO.File]::Open($list, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    $job = New-ClarkCircuitJob
    Write-Host "FMI: '$case'; MPI ranks: $($runtime.MpiRanks); transport: $Transport."
    $solverArguments = @('-n', [string] $runtime.MpiRanks, $solver, $list,
                        '--julia-args', '-O3', '-C', 'generic', '--check-bounds=no', '--inline=yes')
    $server = Start-ClarkCircuitProcess -Job $job -Executable $runtime.MpiExec `
        -Arguments $solverArguments -Directory $application `
        -Environment @{ CLARK_SERVER = '1'; CLARK_SERVER_READY_FILE = $ready; JULIA_NUM_THREADS = '1' }
    Wait-ClarkCircuitReady -Server $server -ReadyPath $ready -TaskDirectory $case -TimeoutSeconds $StartupSeconds
    $client = Start-ClarkCircuitProcess -Job $job -Executable $python `
        -Arguments @('-m', 'clark_fmi', 'run', $case, '--transport', $Transport, '--timeout', [string] $ResponseSeconds) `
        -Directory $componentDirectory -Environment @{ CLARK_SERVER = $null; CLARK_SERVER_READY_FILE = $null; PYTHONUNBUFFERED = '1' }
    $code = Wait-ClarkCircuitCompletion -Server $server -Client $client -DrainTimeoutSeconds $FinishSeconds
    if ($code -ne 0) { throw "Клиент FMI завершился с кодом $code." }
    $owner = @{ schema = 1; server_exit = $server.GetExitCode(); client_exit = $client.GetExitCode();
                mpi_ranks = $runtime.MpiRanks; solver = $solver; utc = [DateTime]::UtcNow.ToString('o') } | ConvertTo-Json
    [IO.File]::WriteAllText((Join-Path $case 'fmi-results\owner-success.json'), $owner, [Text.UTF8Encoding]::new($false))
    Write-Host 'Клиент FMI и MPI-сервер завершились успешно. Результаты: fmi-results.'
}
catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
finally {
    try {
        if ($null -ne $job) { Close-ClarkCircuitJob -Job $job }
    }
    finally {
        if ($null -ne $client) { $client.Dispose() }
        if ($null -ne $server) { $server.Dispose() }
        if ($null -ne $listLock) { $listLock.Dispose() }
        if ($null -ne $caseLock) { $caseLock.Dispose() }
        if ($null -ne $sessionDirectory -and [IO.Directory]::Exists($sessionDirectory)) {
            Remove-Item -LiteralPath $sessionDirectory -Recurse -Force
        }
    }
}
