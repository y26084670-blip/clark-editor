"""Fixed-grid FMI client for Clark; independent of the Julia/MPI runtime."""

__version__ = "0.1.0"
