"""Load our stateless FMI 2.0 Model Exchange residual, not an arbitrary dynamic FMU."""
from pathlib import Path
import shutil
import tempfile
import numpy as np


class ResidualFMU:
    def __init__(self, path, circuit, grid):
        from fmpy import extract, read_model_description
        from fmpy.fmi2 import FMU2Model
        self.directory = tempfile.mkdtemp(prefix='clark-fmu-')
        self.fmu = None
        self.initialized = False
        try:
            description = read_model_description(str(path), validate=True)
            if description.fmiVersion != '2.0' or description.modelExchange is None:
                raise ValueError('Expected FMI 2.0 Model Exchange')
            if description.numberOfContinuousStates or description.numberOfEventIndicators:
                raise ValueError('This coordinator supports only the supplied stateless residual model')
            self.variables = {v.name: v for v in description.modelVariables}
            self.circuit = circuit
            self.n = circuit.n
            extract(str(Path(path).resolve()), unzipdir=self.directory)
            self.fmu = FMU2Model(guid=description.guid, unzipDirectory=self.directory,
                                modelIdentifier=description.modelExchange.modelIdentifier,
                                instanceName='ClarkCircuitResidual')
            self.fmu.instantiate()
            self.fmu.setupExperiment(startTime=0.0)
            self.set('dt', [grid['dt']])
            symmetry = (2 if grid['d7'] >= 0 else 1)*(2 if grid['d9'] >= 0 else 1)
            self.set('symmetry', [symmetry])
            self.fmu.enterInitializationMode()
            for v in description.modelVariables:
                if v.causality == 'input':
                    if v.type != 'Real':
                        raise ValueError('Unexpected non-Real input')
                    self.fmu.setReal([v.valueReference], [0.0])
            self.fmu.exitInitializationMode()
            for _ in range(10):
                event = self.fmu.newDiscreteStates()
                if event[1] or event[4]:
                    raise ValueError('Unexpected termination or timed event in residual FMU')
                if not event[0]:
                    break
            else:
                raise ValueError('FMU initialization event iteration did not converge')
            self.fmu.enterContinuousTimeMode()
            self.initialized = True
        except Exception:
            self.close()
            raise

    def references(self, name, count):
        names = [name] if name in ('dt', 'symmetry', 'neutral', 'previousNeutral') else [
            f'{name}[{i+1}]' for i in range(count)]
        try:
            return [self.variables[k].valueReference for k in names]
        except KeyError as error:
            raise ValueError(f'FMU does not implement the Clark residual contract: {error}') from error

    def set(self, name, values):
        self.fmu.setReal(self.references(name, len(values)), list(map(float, values)))

    def evaluate(self, time, current, flux, resistance, emf, previous, neutral):
        self.fmu.setTime(float(time))
        for name, values in (
                ('current', current), ('previousCurrent', previous['current']),
                ('flux', flux), ('previousFlux', previous['flux']),
                ('fieldResistance', resistance), ('previousFieldVoltage', previous['field_voltage']),
                ('emf', emf), ('previousEmf', previous['emf']),
                ('neutral', [neutral]), ('previousNeutral', [previous['neutral']])):
            self.set(name, values)
        result = np.array(self.fmu.getReal(self.references('residual', self.n+int(self.circuit.floating))))
        if not np.all(np.isfinite(result)):
            raise ValueError('FMU returned a non-finite residual')
        return result

    def close(self):
        if self.fmu is not None:
            try:
                if self.initialized:
                    self.fmu.terminate()
            finally:
                self.fmu.freeInstance()
                self.fmu = None
        shutil.rmtree(self.directory, ignore_errors=True)
