within;
package ClarkCircuit
  model CircuitResidual "CircuitClient discrete equations; history belongs to the coordinator"
    parameter Integer nPhase(min=1)=1;
    parameter Integer nParallel(min=1)=1;
    parameter Boolean floatingNeutral=false;
    final parameter Integer n=nPhase*nParallel;
    parameter Real L[n](each unit="H")=fill(1.0,n);
    parameter Real R[n](each unit="Ohm")=fill(2.0,n);
    parameter Real dt(unit="s", min=1e-300)=0.5 annotation(Evaluate=false);
    parameter Real symmetry=1.0 annotation(Evaluate=false);
    input Real current[n](each unit="A");
    input Real previousCurrent[n](each unit="A");
    input Real flux[n](each unit="Wb");
    input Real previousFlux[n](each unit="Wb");
    input Real fieldResistance[n](each unit="Ohm");
    input Real previousFieldVoltage[n](each unit="V");
    input Real emf[nPhase](each unit="V");
    input Real previousEmf[nPhase](each unit="V");
    input Real neutral(unit="V");
    input Real previousNeutral(unit="V");
    // Branch residuals are volts; the optional last equation is amperes.
    // Preserve CircuitClient's unscaled norm for this comparison model.
    output Real residual[n + (if floatingNeutral then 1 else 0)];
  equation
    for j in 1:n loop
      residual[j] = symmetry*(flux[j]-previousFlux[j])/dt
        + L[j]*(current[j]-previousCurrent[j])/dt
        + 0.5*(symmetry*fieldResistance[j]*current[j]+previousFieldVoltage[j])
        + 0.5*R[j]*(current[j]+previousCurrent[j])
        - 0.5*(emf[div(j-1,nParallel)+1]+previousEmf[div(j-1,nParallel)+1])
        + (if floatingNeutral then 0.5*(neutral+previousNeutral) else 0.0);
    end for;
    if floatingNeutral then
      residual[n+1] = sum(current);
    end if;
    annotation(Documentation(info="Stateless algebraic FMU. No der/pre/when or internal time integrator. Use the fixed-grid Clark coordinator; this is not a general Modelica circuit importer."));
  end CircuitResidual;
end ClarkCircuit;
