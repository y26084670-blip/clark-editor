"""Run from components/FMI: python -m clark_fmi --help."""
import argparse
import sys
import time
from . import workflow
from .transports import Bridge, LegacyFiles


def main():
    parser = argparse.ArgumentParser(description='OpenModelica FMI fixed-grid CircuitClient prototype')
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('doctor', help='Check local Python, FMI and OpenModelica tools')
    p.add_argument('--omc', default='omc')
    p = commands.add_parser('prepare', help='Copy current CircuitClient inputs into a NEW run directory')
    p.add_argument('source')
    p.add_argument('destination')
    p = commands.add_parser('build', help='Compile this case with OpenModelica')
    p.add_argument('directory')
    p.add_argument('--omc', default='omc')
    p.add_argument('--cc', help='Optional OpenModelica C compiler override, e.g. gcc on Linux')
    p = commands.add_parser('run', help='Run local FMU or connect AFTER the field server is ready')
    p.add_argument('directory')
    p.add_argument('--transport', choices=['files', 'zmq'], default='zmq')
    p.add_argument('--endpoint', help='Use an already running bridge on tcp://127.0.0.1:PORT')
    p.add_argument('--timeout', type=float, default=600, help='Seconds per field reply; never retried')
    p = commands.add_parser('bridge', help='Serve one solver task after its ready signal; owner must supervise both processes')
    p.add_argument('directory')
    p.add_argument('--endpoint', default='tcp://127.0.0.1:5555')
    p.add_argument('--timeout', type=float, default=600)
    args = parser.parse_args()
    if args.command == 'doctor':
        return workflow.doctor(args.omc)
    if args.command == 'prepare':
        print(workflow.prepare(args.source, args.destination))
    elif args.command == 'build':
        print(workflow.build(args.directory, args.omc, args.cc))
    elif args.command == 'run':
        print(workflow.run(args.directory, args.transport, args.timeout, args.endpoint))
    elif args.command == 'bridge':
        workflow.read_case(args.directory)
        bridge = Bridge(LegacyFiles(args.directory, args.timeout), args.endpoint).start()
        print(bridge.endpoint, flush=True)
        try:
            while bridge.thread.is_alive():
                time.sleep(.1)
            if bridge.error:
                raise bridge.error
        finally:
            bridge.close()
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (Exception, KeyboardInterrupt) as error:
        print(f'{type(error).__name__}: {error}', file=sys.stderr)
        sys.exit(1)
