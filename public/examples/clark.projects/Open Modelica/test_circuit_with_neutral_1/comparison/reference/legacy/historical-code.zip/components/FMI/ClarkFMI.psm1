﻿# Shared orchestration for the three FMI entry points. Compatible with PowerShell 5.1.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:ComponentDirectory = $PSScriptRoot
. (Join-Path $PSScriptRoot '../../deployment/commands/Invoke-ClarkCircuit.ps1')

function Get-ClarkFMIPath {
    param([Parameter(Mandatory = $true)][string] $Path)
    return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
}

function Read-ClarkFMIJson {
    param([Parameter(Mandatory = $true)][string] $Path)
    return ([IO.File]::ReadAllText($Path, [Text.UTF8Encoding]::new($false, $true)) | ConvertFrom-Json)
}

function Write-ClarkFMIJson {
    param([Parameter(Mandatory = $true)][string] $Path,
          [Parameter(Mandatory = $true)] $Value)
    $temporary = $Path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, (($Value | ConvertTo-Json -Depth 20) + "`n"), [Text.UTF8Encoding]::new($false))
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temporary, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Path) }
    }
    finally { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } }
}

function ConvertTo-ClarkFMIArgument {
    param([AllowEmptyString()][string] $Value)
    # ProcessStartInfo.Arguments uses native quoting, never shell evaluation.
    $result = [Text.StringBuilder]::new('"')
    $slashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq [char] '\') { $slashes++; continue }
        if ($character -eq [char] '"') { [void] $result.Append([char] '\', 2 * $slashes + 1) }
        else { [void] $result.Append([char] '\', $slashes) }
        [void] $result.Append($character)
        $slashes = 0
    }
    [void] $result.Append([char] '\', 2 * $slashes)
    [void] $result.Append('"')
    return $result.ToString()
}

function Get-ClarkFMIHost {
    $windows = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT
    $name = if (-not $windows) { 'pwsh' } elseif ($PSVersionTable.PSEdition -eq 'Desktop') { 'powershell.exe' } else { 'pwsh.exe' }
    return Join-Path $PSHOME $name
}

function Invoke-ClarkFMIProcess {
    param([Parameter(Mandatory = $true)][string] $Executable,
          [Parameter(Mandatory = $true)][AllowEmptyCollection()][AllowEmptyString()][string[]] $Arguments,
          [Parameter(Mandatory = $true)][string] $LogPath,
          [string] $Directory = $script:ComponentDirectory,
          [hashtable] $Environment = @{},
          [switch] $AllowFailure)
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $Executable
    $start.Arguments = ($Arguments | ForEach-Object { ConvertTo-ClarkFMIArgument $_ }) -join ' '
    $start.WorkingDirectory = $Directory
    $start.UseShellExecute = $false
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.RedirectStandardInput = $true
    $start.StandardOutputEncoding = [Text.UTF8Encoding]::new($false)
    $start.StandardErrorEncoding = [Text.UTF8Encoding]::new($false)
    foreach ($key in @('PYTHONUTF8', 'PYTHONUNBUFFERED')) { $start.EnvironmentVariables[$key] = '1' }
    $start.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8'
    foreach ($key in $Environment.Keys) {
        if ($null -eq $Environment[$key]) { $start.EnvironmentVariables.Remove($key) }
        else { $start.EnvironmentVariables[$key] = [string] $Environment[$key] }
    }
    $record = [ordered] @{ executable = $Executable; arguments = $Arguments; directory = $Directory;
        started_utc = [DateTime]::UtcNow.ToString('o'); exit_code = $null; error = $null }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    $writer = $null
    $started = $false
    try {
        # CreateNew preserves earlier evidence if a caller mistakenly reuses a log name.
        $file = [IO.File]::Open($LogPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        $writer = [IO.StreamWriter]::new($file, [Text.UTF8Encoding]::new($false))
        $writer.AutoFlush = $true
        Write-Host ("[{0}] {1}" -f [IO.Path]::GetFileNameWithoutExtension($LogPath), $Executable)
        $started = $process.Start()
        $process.StandardInput.Close()
        $stdout = $process.StandardOutput.ReadLineAsync()
        $stderr = $process.StandardError.ReadLineAsync()
        # Drain both streams concurrently, with bounded memory and live console output.
        # stderr text is not converted into PowerShell ErrorRecords (notably on 5.1).
        while ($null -ne $stdout -or $null -ne $stderr) {
            if ($null -ne $stdout -and $stdout.IsCompleted) {
                $line = $stdout.GetAwaiter().GetResult()
                if ($null -eq $line) { $stdout = $null }
                else { $writer.WriteLine($line); Write-Host $line; $stdout = $process.StandardOutput.ReadLineAsync() }
            }
            if ($null -ne $stderr -and $stderr.IsCompleted) {
                $line = $stderr.GetAwaiter().GetResult()
                if ($null -eq $line) { $stderr = $null }
                else { $writer.WriteLine($line); Write-Host $line; $stderr = $process.StandardError.ReadLineAsync() }
            }
            if (($null -eq $stdout -or -not $stdout.IsCompleted) -and
                ($null -eq $stderr -or -not $stderr.IsCompleted)) { Start-Sleep -Milliseconds 20 }
        }
        $process.WaitForExit()
        $record.exit_code = $process.ExitCode
    }
    catch { $record.error = $_.Exception.Message; throw }
    finally {
        try {
            if ($started -and -not $process.HasExited) {
                # A child Run-ClarkFMI/Invoke-ClarkCircuit owns the MPI job object.
                # Killing that owner closes its handles and releases the whole job.
                $process.Kill()
                [void] $process.WaitForExit(5000)
            }
        }
        finally {
            $process.Dispose()
            if ($null -ne $writer) {
                $writer.Dispose()
                $record.finished_utc = [DateTime]::UtcNow.ToString('o')
                Write-ClarkFMIJson -Path ($LogPath + '.json') -Value $record
            }
        }
    }
    if ($record.exit_code -ne 0 -and -not $AllowFailure) {
        throw "Process exit code $($record.exit_code); see '$LogPath'."
    }
    return [int] $record.exit_code
}

function Invoke-ClarkFMIPython {
    param($Settings, [string[]] $Arguments, [string] $LogPath, [hashtable] $Environment = @{}, [switch] $AllowFailure)
    return Invoke-ClarkFMIProcess -Executable $Settings.pythonExe -Arguments $Arguments `
        -LogPath $LogPath -Environment $Environment -AllowFailure:$AllowFailure
}

function Get-ClarkFMISettings {
    param([string] $SettingsPath = (Join-Path $script:ComponentDirectory 'fmi-settings.json'))
    $path = Get-ClarkFMIPath $SettingsPath
    if (-not [IO.File]::Exists($path)) { throw "Run Initialize-ClarkFMI.ps1 first; settings not found: '$path'." }
    $settings = Read-ClarkFMIJson $path
    if ($settings.schema -ne 1) { throw 'Unsupported fmi-settings.json schema.' }
    foreach ($name in @('pythonExe', 'omcExe', 'appRoot', 'runsDirectory')) {
        $property = $settings.PSObject.Properties[$name]
        if ($null -eq $property -or $property.Value -isnot [string] -or
            [string]::IsNullOrWhiteSpace($property.Value) -or -not [IO.Path]::IsPathRooted($property.Value)) {
            throw "Settings require an absolute path: $name. Run Initialize-ClarkFMI.ps1."
        }
    }
    foreach ($path in @($settings.pythonExe, $settings.omcExe)) {
        if (-not [IO.File]::Exists($path)) { throw "Program not found: '$path'. Run Initialize-ClarkFMI.ps1." }
    }
    $hash = (Get-FileHash -LiteralPath (Join-Path $script:ComponentDirectory 'requirements.txt') -Algorithm SHA256).Hash
    if ($settings.requirements_sha256 -ne $hash) { throw 'requirements.txt changed; run Initialize-ClarkFMI.ps1.' }
    return $settings
}

function New-ClarkFMIRun {
    param([Parameter(Mandatory = $true)] $Settings,
          [Parameter(Mandatory = $true)][string] $Kind,
          [string] $Source = '', [string] $RunDirectory = '')
    if ($Source) {
        $Source = Get-ClarkFMIPath $Source
        if (-not [IO.Directory]::Exists($Source)) { throw "Source directory not found: '$Source'." }
    }
    if (-not $RunDirectory) {
        $id = $Kind + '-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0, 8)
        $RunDirectory = Join-Path $Settings.runsDirectory $id
    }
    $root = Get-ClarkFMIPath $RunDirectory
    if ($Source) {
        $sourceRoot = $Source.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
        $comparison = if ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
        if ($root.Equals($sourceRoot, $comparison) -or $root.StartsWith($sourceRoot + [IO.Path]::DirectorySeparatorChar, $comparison)) {
            throw 'RunDirectory must be outside the original task.'
        }
    }
    if ([IO.Directory]::Exists($root) -or [IO.File]::Exists($root)) { throw "RunDirectory already exists: '$root'. Choose a new directory." }
    [void] [IO.Directory]::CreateDirectory($root)
    $record = [ordered] @{ schema = 1; id = [guid]::NewGuid().ToString('N'); kind = $Kind;
        source = $Source; directory = $root; started_utc = [DateTime]::UtcNow.ToString('o');
        finished_utc = $null; complete = $false; error = $null;
        powershell = $PSVersionTable.PSVersion.ToString(); settings = $Settings; results = @() }
    $manifest = Join-Path $root 'launch.json'
    $claim = [IO.File]::Open($manifest, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $bytes = [Text.UTF8Encoding]::new($false).GetBytes(($record | ConvertTo-Json -Depth 20))
        $claim.Write($bytes, 0, $bytes.Length)
    }
    finally { $claim.Dispose() }
    $reports = Join-Path $root 'reports'
    [void] [IO.Directory]::CreateDirectory($reports)
    Write-Host "Run directory: $root"
    return [pscustomobject] @{ Directory = $root; Reports = $reports; Manifest = $manifest; Record = $record }
}

function Save-ClarkFMIRun {
    param($Run, [switch] $Complete, [string] $ErrorMessage = '')
    $Run.Record.complete = [bool] $Complete
    $Run.Record.error = if ($ErrorMessage) { $ErrorMessage } else { $null }
    $Run.Record.finished_utc = [DateTime]::UtcNow.ToString('o')
    Write-ClarkFMIJson -Path $Run.Manifest -Value $Run.Record
}

function Save-ClarkFMIEnvironment {
    param($Settings, [string] $Reports)
    [void] (Invoke-ClarkFMIPython $Settings @('-m', 'clark_fmi', 'doctor', '--omc', $Settings.omcExe) (Join-Path $Reports 'doctor.txt'))
    [void] (Invoke-ClarkFMIPython $Settings @('-m', 'pip', 'freeze') (Join-Path $Reports 'python-packages.txt'))
    $hashes = [ordered] @{}
    foreach ($path in @(Get-ChildItem -LiteralPath $script:ComponentDirectory -File) +
                       @(Get-ChildItem -LiteralPath (Join-Path $script:ComponentDirectory 'clark_fmi') -File) +
                       @(Get-ChildItem -LiteralPath (Join-Path $script:ComponentDirectory 'modelica') -File)) {
        if ($path.Extension -in @('.ps1', '.psm1', '.py', '.mo') -or $path.Name -eq 'requirements.txt') {
            $relative = $path.FullName.Substring($script:ComponentDirectory.Length + 1).Replace('\', '/')
            $hashes[$relative] = (Get-FileHash -LiteralPath $path.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    }
    foreach ($relative in @('config/runtime.json', 'runtime/runtime-manifest.json')) {
        $path = Join-Path $Settings.appRoot $relative
        if ([IO.File]::Exists($path)) {
            [IO.File]::Copy($path, (Join-Path $Reports ([IO.Path]::GetFileName($path))), $false)
        }
    }
    Write-ClarkFMIJson (Join-Path $Reports 'component-hashes.json') $hashes
}

function Assert-ClarkFMIInstalled {
    param($Settings)
    $runtime = Get-ClarkCircuitRuntime -ApplicationRoot $Settings.appRoot
    Assert-ClarkCircuitExecutablePath (Join-Path $Settings.appRoot 'runtime/bin/clark3XX64.exe')
    return $runtime
}

function Invoke-ClarkFMICase {
    param($Settings, [string] $Case, [string] $Reports, [string] $Label = 'run',
          [ValidateSet('files', 'zmq')][string] $Transport = 'zmq', [int] $Processes = 0,
          [int] $StartupSeconds = 300, [int] $ResponseSeconds = 600, [int] $FinishSeconds = 30)
    $circuit = Read-ClarkFMIJson (Join-Path $Case 'circuit.json')
    $server = @($circuit.branches | Where-Object { $_.pulse -gt 0 }).Count -gt 0
    $ranks = $null
    if ($server) {
        Assert-ClarkCircuitTask -TaskDirectory $Case
        $runtime = Assert-ClarkFMIInstalled $Settings
        $ranks = if ($Processes -gt 0) { $Processes } else { $runtime.MpiRanks }
    }
    [void] (Invoke-ClarkFMIPython $Settings @('-m', 'clark_fmi', 'build', $Case, '--omc', $Settings.omcExe) (Join-Path $Reports ($Label + '-build.txt')))
    $log = Join-Path $Reports ($Label + '-console.txt')
    if ($server) {
        $arguments = @('-NoLogo', '-NoProfile', '-NonInteractive', '-File', (Join-Path $script:ComponentDirectory 'Run-ClarkFMI.ps1'),
            '-CaseDirectory', $Case, '-AppRoot', $Settings.appRoot, '-PythonExe', $Settings.pythonExe,
            '-Transport', $Transport, '-Processes', [string] $ranks,
            '-StartupSeconds', [string] $StartupSeconds, '-ResponseSeconds', [string] $ResponseSeconds, '-FinishSeconds', [string] $FinishSeconds)
        [void] (Invoke-ClarkFMIProcess -Executable (Get-ClarkFMIHost) -Arguments $arguments -LogPath $log)
    }
    else { [void] (Invoke-ClarkFMIPython $Settings @('-m', 'clark_fmi', 'run', $Case) $log) }
    $resultPath = Join-Path $Case 'fmi-results'
    $result = Read-ClarkFMIJson (Join-Path $resultPath 'run.json')
    if ($result.complete -ne $true) { throw "Incomplete FMI result: '$resultPath'." }
    if ($server) {
        $owner = Read-ClarkFMIJson (Join-Path $resultPath 'owner-success.json')
        if ($owner.server_exit -ne 0 -or $owner.client_exit -ne 0 -or $owner.mpi_ranks -ne $ranks) {
            throw 'The owner did not confirm successful client/server exit with the requested MPI ranks.'
        }
    }
    return [pscustomobject] @{ label = $Label; case = $Case; results = $resultPath;
        transport = $result.transport; mpi_ranks = $ranks; complete = $true;
        mpiexec = $(if ($server) { $runtime.MpiExec } else { $null }) }
}

Export-ModuleMember -Function *-ClarkFMI*
