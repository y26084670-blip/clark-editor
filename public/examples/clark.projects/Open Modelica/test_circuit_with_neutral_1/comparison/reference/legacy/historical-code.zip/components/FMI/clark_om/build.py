"""Build and package a native OM client. Python performs build operations only."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import posixpath
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

from .prepare import model_id, read_pulses, write_new

COMPONENT = Path(__file__).resolve().parents[1]
SUPPORTED_OM = '1.27.1'


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError(f'Duplicate JSON key: {key}')
            result[key] = value
        return result
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=pairs,
                      parse_constant=lambda text: (_ for _ in ()).throw(ValueError(text)))


def mos_string(path):
    return json.dumps(str(path).replace('\\', '/'), ensure_ascii=False)


def run(args, cwd, env, log):
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        process = subprocess.Popen([str(a) for a in args], cwd=cwd, env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, encoding='utf-8', errors='replace')
        for line in process.stdout:
            stream.write(line)
            print(line, end='', flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f'Process exit {code}; see {log}')


def replace_once(text, old, new, description):
    if text.count(old) != 1:
        raise RuntimeError(f'Unsupported OM generated runtime: {description}')
    return text.replace(old, new, 1)


def patch_runtime(directory, om_home):
    """Patch only the generated build, leaving the installed OM unchanged.

    Hooks are after initialization, after all convergence checks, and after
    _main_SimulationRuntime returns. Result emit() is NOT an acceptance hook.
    """
    include = om_home / 'include/omc/c'
    original = include / 'simulation/solver/perform_simulation.c.inc'
    runtime = original.read_text(encoding='utf-8')
    runtime = replace_once(runtime, '  fmtInit(data, &fmt);',
                           '  fmtInit(data, &fmt);\n  clark_om_start(data, threadData, solverInfo);', 'initial endpoint')
    runtime = replace_once(runtime, '        success = 1;',
                           '        clark_om_accept(data, threadData);\n        success = 1;', 'accepted endpoint')
    # A protocol failure must not enter OM's assertion-retry path.
    runtime = replace_once(runtime, '      if (!success) { /* catch */',
                           '      if (clark_session_failed()) { retValue = -1; break; }\n'
                           '      if (!success) { /* catch */', 'poisoned session')
    # Copied includes previously resolved relative to OM's solver directory.
    runtime = re.sub(r'#include "([^\"]+)"',
                     lambda match: '#include "' + posixpath.normpath('simulation/solver/' + match[1]) + '"',
                     runtime)
    (directory / 'clark_perform_simulation.c.inc').write_text(runtime, encoding='utf-8')
    model_c = directory / 'clark_om_client.c'
    source = model_c.read_text(encoding='utf-8')
    source = replace_once(source, '#include <simulation/solver/perform_simulation.c.inc>',
                          '#include "clark_runtime.h"\n#include "clark_perform_simulation.c.inc"', 'runtime include')
    old = 'res = _main_SimulationRuntime(argc, newargv, &data, threadData);'
    new = ('if (!clark_session_begin()) {\n'
           '          fprintf(stderr, "Clark OM: %s\\n", clark_session_error()); res = 1;\n'
           '        } else {\n'
           '          res = _main_SimulationRuntime(argc, newargv, &data, threadData);\n'
           '          res = clark_session_end(res);\n'
           '        }')
    source = replace_once(source, old, new, 'runtime ownership')
    model_c.write_text(source, encoding='utf-8')
    for name in ('clark_adapter.h', 'clark_runtime.h'):
        shutil.copy2(COMPONENT / 'modelica/Clark/Resources/Include' / name, directory / name)
    return sha256(original)


def tools_environment(omc, tool_bin=None):
    home = omc.parent.parent
    candidates = ([Path(tool_bin).resolve()] if tool_bin else []) + [
        home / 'tools/msys/ucrt64/bin', home / 'tools/msys/mingw64/bin',
        home / 'tools/msys/usr/bin', home / 'bin']
    bins = [p for p in candidates if p.is_dir()]
    env = os.environ.copy()
    env['OPENMODELICAHOME'] = str(home)
    env['PATH'] = os.pathsep.join(map(str, bins)) + os.pathsep + env.get('PATH', '')
    return home, bins, env


def find_tool(names, env):
    for name in names:
        path = shutil.which(name, path=env['PATH'])
        if path:
            return Path(path)
    raise FileNotFoundError('OM build tool not found: ' + ' / '.join(names))


def collect_dlls(executable, output, bins, env):
    """Resolve the PE import closure; never copy the whole OM installation."""
    objdump = find_tool(('objdump.exe', 'objdump'), env)
    search = [executable.parent] + bins
    index = {}
    for directory in search:
        for path in directory.glob('*'):
            if path.suffix.lower() == '.dll':
                index.setdefault(path.name.lower(), path)
    system = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32'
    queue, seen = [executable], set()
    while queue:
        binary = queue.pop()
        listing = subprocess.check_output([str(objdump), '-p', str(binary)], env=env,
                                          text=True, encoding='utf-8', errors='replace')
        for name in re.findall(r'DLL Name:\s*(\S+)', listing):
            key = name.lower()
            if key in seen:
                continue
            seen.add(key)
            if key.startswith(('api-ms-win-', 'ext-ms-win-')) or (system / name).is_file():
                continue
            dependency = index.get(key)
            if dependency is None:
                raise FileNotFoundError(f'Unresolved native dependency: {name} (from {binary.name})')
            destination = output / dependency.name
            shutil.copy2(dependency, destination)
            queue.append(dependency)


def make_descriptor(selection, data, om_version, runtime_hash, built):
    if data['schema'] != 'clark-circuit/2':
        raise ValueError('Circuit requires clark-circuit/2 with task pulse references')
    n = data['phases']*data['parallel']
    variables = lambda name: [f'{name}[{k}]' for k in range(1, n+1)]
    return dict(
        schema='clark-om-model/1', model=selection['model'], version=selection['version'],
        executable='clark_om_client.exe', initFile='clark_om_client_init.xml',
        dataSchema=data['schema'], modelClass='ClarkGenerated',
        structural={key: data[key] for key in ('phases', 'parallel', 'floatingNeutral')},
        omc=om_version, modelica='4.0.0', platform='windows-x86_64',
        builtUtc=datetime.now(timezone.utc).isoformat(), runtimeSourceSha256=runtime_hash,
        numerics=dict(solver='gbode', method='trapezoid', controller='const', initialCurrent='zero'),
        inputs=[dict(kind='AMP', variables=variables('fieldPort.current'))],
        outputs=[dict(kind='PSI', variables=variables('fieldPort.flux')),
                 dict(kind='RSP', variables=variables('fieldPort.resistance'))],
        history=variables('q')+variables('drive')+['neutral'],
        residualVariable='residualNorm', resultFile='currents.tsv',
        results=[dict(variable=f'current[{k}]', column=f'I{k}_A') for k in range(1,n+1)] +
                [dict(variable='neutral', column='neutral_V'),
                 dict(variable='residualNorm', column='residual_norm')],
        runtimeParameters=variables('L')+variables('R')+['dt', 'emfFile'],
        gridParameter='dt', tableFileParameter='emfFile',
        arraySizes=dict(branches=n, emf=data['phases']),
        parameterBindings=[dict(parameter=f'{key}[{k+1}]', path=['branches', k, source], type='real', minimum=0)
                           for k in range(n) for key, source in (('L', 'L_H'), ('R', 'R_Ohm'))],
        tables=[dict(name=f'emf{k+1}', source='task-pulse', pulsePath=['emf', k, 'pulse'],
                     scalePath=['emf', k, 'amplitude']) for k in range(data['phases'])],
        files={p.relative_to(built).as_posix(): sha256(p) for p in sorted(built.rglob('*')) if p.is_file()})


def make_editor_preset(selection, data, coupling, descriptor, label=None):
    """A data-only editor extension, derived from the exact packaged interface."""
    if label is not None and (not isinstance(label, str) or not label.strip()):
        raise ValueError('Editor preset label must be nonempty text')
    keys = ('dataSchema', 'structural', 'arraySizes', 'parameterBindings', 'tables', 'inputs', 'outputs')
    return dict(schema='clark-om-preset/1', label=label or selection['model'],
                selection=selection, data=data, coupling=coupling,
                contract={key: descriptor[key] for key in keys})


def build(source, omc, output=None, tool_bin=None, model_spec=None):
    if os.name != 'nt':
        raise RuntimeError('The delivered executable targets Windows x64; build with the installed OM on Windows')
    source, omc = Path(source).resolve(), Path(omc).resolve()
    inputs = source / 'input3XX'
    selection = read_json(inputs / 'om-client.json')
    data_name = selection.get('dataFile', '')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}', data_name) or '..' in data_name:
        raise ValueError('Invalid model data file name')
    data = read_json(inputs / data_name)
    coupling_name = selection.get('couplingFile', '')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}', coupling_name) or '..' in coupling_name:
        raise ValueError('Invalid coupling file name')
    coupling = read_json(inputs / coupling_name)
    if coupling.get('schema') != 'clark-server/1':
        raise ValueError('Unsupported coupling schema')
    if selection.get('schema') != 'clark-om-client/1':
        raise ValueError('Unsupported client/data schema; first run Prepare-ClarkOM.ps1')
    spec = read_json(Path(model_spec)) if model_spec else None
    if spec is None:
        if data.get('schema') != 'clark-circuit/2':
            raise ValueError('A custom model requires --model-spec')
        for key in ('phases', 'parallel'):
            if type(data.get(key)) is not int or not 1 <= data[key] <= 10000:
                raise ValueError(f'Invalid structural parameter {key}')
        if type(data.get('floatingNeutral')) is not bool or data['phases']*data['parallel'] > 10000:
            raise ValueError('Invalid circuit dimensions/connection')
        ident = model_id(data['phases'], data['parallel'], data['floatingNeutral'])
        if data['floatingNeutral'] and data['phases']*data['parallel'] < 2:
            raise ValueError('A floating circuit needs at least two branches')
        model_class = 'Clark.Examples.Circuit'
        modifiers = dict(nPhase=data['phases'], nParallel=data['parallel'], floatingNeutral=data['floatingNeutral'])
        if 'amplitude' in data:
            raise ValueError('clark-circuit/2 has per-phase amplitude, not a global amplitude')
        pulses = read_pulses((inputs/'amplitudes.txt').read_bytes())
        if not isinstance(data.get('emf'), list) or len(data['emf']) != data['phases']:
            raise ValueError('One EMF pulse source is required per phase')
        for emf in data['emf']:
            if not isinstance(emf, dict) or set(emf) != {'pulse', 'amplitude'}:
                raise ValueError('Each EMF source requires only pulse and amplitude')
            if type(emf['pulse']) is not int or not 1 <= emf['pulse'] <= len(pulses):
                raise ValueError('EMF pulse index is outside amplitudes.txt')
            if type(emf['amplitude']) not in (int, float) or not math.isfinite(emf['amplitude']):
                raise ValueError('EMF amplitude must be finite')
            pulse = pulses[emf['pulse']-1]
            if any(not math.isfinite(value*emf['amplitude']) for value in pulse['impuls'][pulse['n']:]):
                raise ValueError('Scaled EMF values must be finite')
    else:
        if spec.get('schema') != 'clark-om-build/1' or data.get('schema') != spec.get('dataSchema'):
            raise ValueError('Unsupported custom build specification/data schema')
        ident, model_class, modifiers = spec['model'], spec['modelClass'], spec.get('modifiers', {})
        for key, expected in spec['structural'].items():
            if type(data.get(key)) is not type(expected) or data[key] != expected:
                raise ValueError(f'Custom structural parameter differs: {key}')
        for table in spec['tables']:
            if table.get('source') != 'task-pulse':
                raise ValueError('Model tables require source=task-pulse; inline points are unsupported')
    if selection.get('model') != ident or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}', ident) or '..' in ident:
        raise ValueError('Selected model does not match the build specification')
    if not re.fullmatch(r'[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*', model_class):
        raise ValueError('Invalid Modelica class name')
    version = selection['version']
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}', version) or '..' in version:
        raise ValueError('Invalid model version')
    root = Path(output).resolve() if output else COMPONENT.parents[1] / 'build/components/OpenModelica'
    destination = root / ident / version
    if destination.exists():
        raise FileExistsError(f'Build already exists: {destination}; use a new version')
    home, bins, env = tools_environment(omc, tool_bin)
    om_version = subprocess.check_output([str(omc), '--version'], env=env, text=True).strip()
    if not re.search(r'\bv'+re.escape(SUPPORTED_OM)+r'(?:\s|$)', om_version):
        raise RuntimeError(f'Native hook requires OpenModelica {SUPPORTED_OM}; found {om_version}')
    root.mkdir(parents=True, exist_ok=True)
    reports = COMPONENT / 'runs'
    reports.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='native-build-', dir=reports))
    print(f'Build directory: {work}', flush=True)
    # Keep a self-contained source copy for developers and license/source delivery.
    package = work / 'source/Clark'
    shutil.copytree(COMPONENT / 'modelica/Clark', package)
    modifier_text = []
    for key, value in modifiers.items():
        if not re.fullmatch(r'[A-Za-z_]\w*', key) or type(value) not in (int, float, bool, str):
            raise ValueError('Structural modifiers must be named scalars')
        modifier_text.append(f'{key}={json.dumps(value, ensure_ascii=False, allow_nan=False)}')
    model = (f'within ;\nmodel ClarkGenerated\n  extends {model_class}'
             f'({", ".join(modifier_text)});\nend ClarkGenerated;\n')
    (work / 'ClarkGenerated.mo').write_text(model, encoding='utf-8')
    custom_load = ''
    if spec is not None:
        source_package = (Path(model_spec).resolve().parent / spec['packageFile']).resolve()
        custom = work/'source/UserModel'
        shutil.copytree(source_package.parent, custom)
        custom_load = f'loadFile({mos_string(custom/source_package.name)});\ngetErrorString();\n'
    script = ('loadModel(Modelica, {"4.0.0"});\ngetErrorString();\n'
              'if getVersion(Modelica) <> "4.0.0" then\n'
              '  print("This client requires Modelica 4.0.0\\n");\n  exit(1);\nend if;\n'
              f'loadFile({mos_string(package / "package.mo")});\ngetErrorString();\n' + custom_load +
              f'loadFile({mos_string(work / "ClarkGenerated.mo")});\ngetErrorString();\n'
              'buildModel(ClarkGenerated, method="gbode", fileNamePrefix="clark_om_client", '
              'outputFormat="mat", startTime=0, stopTime=1.5, numberOfIntervals=3, tolerance=1e-10);\n'
              'getErrorString();\n')
    (work / 'build.mos').write_text(script, encoding='utf-8')
    run([omc, work/'build.mos'], work, env, work/'omc-build.txt')
    executable = work / 'clark_om_client.exe'
    init = work / 'clark_om_client_init.xml'
    if not executable.is_file() or not init.is_file():
        raise RuntimeError(f'OM did not build the model; inspect {work / "omc-build.txt"}')
    runtime_hash = patch_runtime(work, home)
    make = find_tool(('mingw32-make.exe', 'make.exe', 'make'), env)
    run([make, '-B', '-f', 'clark_om_client.makefile'], work, env, work/'native-link.txt')
    built = work / 'package'
    built.mkdir()
    shutil.copy2(executable, built/executable.name)
    shutil.copy2(init, built/init.name)
    info = work / 'clark_om_client_info.json'
    if info.is_file():
        shutil.copy2(info, built/info.name)
    collect_dlls(executable, built, bins, env)
    shutil.copytree(work/'source', built/'source')
    shutil.copy2(work/'ClarkGenerated.mo', built/'source/ClarkGenerated.mo')
    shutil.copy2(work/'clark_perform_simulation.c.inc', built/'source/clark_perform_simulation.c.inc')
    # Preserve available upstream licensing material with runtime dependencies.
    for directory in (home/'share/omc/licenses', home/'share/licenses'):
        if directory.is_dir():
            shutil.copytree(directory, built/'licenses'/directory.parent.name, dirs_exist_ok=True)
    for name in ('COPYING', 'COPYING.txt', 'LICENSE', 'LICENSE.txt'):
        if (home/name).is_file():
            (built/'licenses').mkdir(exist_ok=True)
            shutil.copy2(home/name, built/'licenses'/name)
    if spec is None:
        descriptor = make_descriptor(selection, data, om_version, runtime_hash, built)
    else:
        keys = ('dataSchema', 'structural', 'inputs', 'outputs', 'history', 'residualVariable',
                'resultFile', 'results', 'parameterBindings', 'tables', 'gridParameter', 'tableFileParameter')
        descriptor = {key: spec[key] for key in keys}
        descriptor['arraySizes'] = spec.get('arraySizes', {})
        descriptor.update(schema='clark-om-model/1', model=ident, version=version, modelClass=model_class,
                          executable='clark_om_client.exe', initFile='clark_om_client_init.xml',
                          omc=om_version, modelica='4.0.0', platform='windows-x86_64',
                          builtUtc=datetime.now(timezone.utc).isoformat(), runtimeSourceSha256=runtime_hash,
                          numerics=dict(solver='gbode', method='trapezoid', controller='const'),
                          runtimeParameters=[v['parameter'] for v in spec['parameterBindings']] +
                                            [v for v in (spec['gridParameter'], spec['tableFileParameter']) if v],
                          files={p.relative_to(built).as_posix(): sha256(p) for p in sorted(built.rglob('*')) if p.is_file()})
    # Overrides must exist in this exact compiled artifact (not only in Modelica source).
    variables = {v.get('name'): v for v in ET.parse(init).iter('ScalarVariable')}
    if spec is None:
        amplitude = variables.get('amplitude')
        real = amplitude.find('Real') if amplitude is not None else None
        if real is None or float(real.get('start', 'nan')) != 1:
            raise RuntimeError('Pulse-source Circuit requires the internal amplitude default to be one')
    for name in descriptor['runtimeParameters']:
        variable = variables.get(name)
        if variable is None or variable.get('variability') != 'parameter':
            raise RuntimeError(f'OM did not retain runtime parameter {name}; see generated init XML')
    observed = [name for group in descriptor['inputs']+descriptor['outputs'] for name in group['variables']]
    observed += descriptor['history'] + [item['variable'] for item in descriptor['results']]
    if descriptor['residualVariable']:
        observed.append(descriptor['residualVariable'])
    for name in observed:
        variable = variables.get(name)
        if variable is None or variable.find('Real') is None:
            raise RuntimeError(f'OM did not retain observed Real variable {name}; see generated init XML')
    preset = make_editor_preset(selection, data, coupling, descriptor,
                                spec.get('label') if spec else None)
    write_new(built/'editor-preset.json', preset)
    descriptor['files']['editor-preset.json'] = sha256(built/'editor-preset.json')
    write_new(built/'model.json', descriptor)
    destination.parent.mkdir(parents=True, exist_ok=True)
    built.rename(destination)
    print(f'Compiled model: {destination}', flush=True)
    return destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--omc', required=True, type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--tool-bin', type=Path)
    parser.add_argument('--model-spec', type=Path, help='Developer build specification for another Modelica model')
    args = parser.parse_args()
    build(args.source, args.omc, args.output, args.tool_bin, args.model_spec)


if __name__ == '__main__':
    main()
